"""Storage package for Bakery Order Register."""
