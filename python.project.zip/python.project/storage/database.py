"""Data Storage Layer for Bakery Order Register (CSV & JSON Management)."""

import csv
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

import config


def init_storage() -> None:
    """Ensure data files and backup directories exist."""
    config.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    if not config.ORDERS_CSV.exists():
        with open(config.ORDERS_CSV, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_FIELDNAMES)
            writer.writeheader()

    if not config.CUSTOMERS_JSON.exists():
        with open(config.CUSTOMERS_JSON, mode="w", encoding="utf-8") as f:
            json.dump([], f, indent=2)


def load_orders() -> List[Dict[str, Any]]:
    """
    Loads all orders from CSV into a list of dictionaries with typed values.
    Handles missing files or malformed rows gracefully.
    """
    init_storage()
    orders: List[Dict[str, Any]] = []

    if not config.ORDERS_CSV.exists():
        return orders

    try:
        with open(config.ORDERS_CSV, mode="r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if not row or not row.get("order_id"):
                    continue
                try:
                    typed_row = {
                        "order_id": str(row.get("order_id", "")).strip(),
                        "customer_id": str(row.get("customer_id", "")).strip(),
                        "customer_name": str(row.get("customer_name", "")).strip(),
                        "customer_phone": str(row.get("customer_phone", "")).strip(),
                        "cake_type": str(row.get("cake_type", "Birthday Cake")).strip(),
                        "flavour": str(row.get("flavour", "Chocolate")).strip(),
                        "weight_kg": float(row.get("weight_kg", 1.0)),
                        "quantity": int(float(row.get("quantity", 1))),
                        "cake_message": str(row.get("cake_message", "")).strip(),
                        "price_per_kg": float(row.get("price_per_kg", 0.0)),
                        "extra_charges": float(row.get("extra_charges", 0.0)),
                        "total_amount": float(row.get("total_amount", 0.0)),
                        "advance_paid": float(row.get("advance_paid", 0.0)),
                        "pending_amount": float(row.get("pending_amount", 0.0)),
                        "payment_status": str(row.get("payment_status", "Pending")).strip(),
                        "order_date": str(row.get("order_date", "")).strip(),
                        "pickup_date": str(row.get("pickup_date", "")).strip(),
                        "pickup_time": str(row.get("pickup_time", "18:00")).strip(),
                        "order_status": str(row.get("order_status", "Pending")).strip(),
                        "special_notes": str(row.get("special_notes", "")).strip(),
                    }
                    orders.append(typed_row)
                except (ValueError, TypeError):
                    # Continue loading other rows if one corrupted row is found
                    continue
    except Exception as e:
        print(f"Warning: Could not read orders file ({e}). Starting with empty or partial list.")

    return orders


def save_orders(orders: List[Dict[str, Any]]) -> bool:
    """
    Saves all orders to CSV atomically using a temporary file.
    """
    init_storage()
    try:
        temp_fd, temp_path = tempfile.mkstemp(
            dir=config.STORAGE_DIR,
            prefix="orders_",
            suffix=".tmp"
        )
        os.close(temp_fd)

        with open(temp_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_FIELDNAMES)
            writer.writeheader()
            for order in orders:
                # Ensure all fieldnames exist in dict
                clean_row = {}
                for field in config.CSV_FIELDNAMES:
                    clean_row[field] = order.get(field, "")
                writer.writerow(clean_row)

        shutil.move(temp_path, config.ORDERS_CSV)
        return True
    except Exception as e:
        print(f"Error saving orders: {e}")
        return False


def load_customers() -> List[Dict[str, Any]]:
    """Loads customer records from JSON file."""
    init_storage()
    if not config.CUSTOMERS_JSON.exists():
        return []

    try:
        with open(config.CUSTOMERS_JSON, mode="r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []
    except Exception:
        return []


def save_customers(customers: List[Dict[str, Any]]) -> bool:
    """Saves customer records to JSON file atomically."""
    init_storage()
    try:
        temp_fd, temp_path = tempfile.mkstemp(
            dir=config.STORAGE_DIR,
            prefix="cust_",
            suffix=".tmp"
        )
        os.close(temp_fd)

        with open(temp_path, mode="w", encoding="utf-8") as f:
            json.dump(customers, f, indent=2, ensure_ascii=False)

        shutil.move(temp_path, config.CUSTOMERS_JSON)
        return True
    except Exception as e:
        print(f"Error saving customers: {e}")
        return False


def get_next_order_id(orders: Optional[List[Dict[str, Any]]] = None) -> str:
    """Generates the next sequential Order ID (e.g. B001, B002)."""
    if orders is None:
        orders = load_orders()
    max_num = 0
    for o in orders:
        oid = str(o.get("order_id", "")).strip()
        if oid.startswith("B") and oid[1:].isdigit():
            max_num = max(max_num, int(oid[1:]))
    return f"B{max_num + 1:03d}"


def get_next_customer_id(customers: Optional[List[Dict[str, Any]]] = None) -> str:
    """Generates the next sequential Customer ID (e.g. C001, C002)."""
    if customers is None:
        customers = load_customers()
    max_num = 0
    for c in customers:
        cid = str(c.get("customer_id", "")).strip()
        if cid.startswith("C") and cid[1:].isdigit():
            max_num = max(max_num, int(cid[1:]))
    return f"C{max_num + 1:03d}"


def backup_data() -> Tuple[bool, str]:
    """
    Creates a timestamped backup of both orders.csv and customers.json in backups folder.
    """
    init_storage()
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_folder = config.BACKUP_DIR / f"backup_{timestamp}"
        backup_folder.mkdir(parents=True, exist_ok=True)

        if config.ORDERS_CSV.exists():
            shutil.copy2(config.ORDERS_CSV, backup_folder / "orders.csv")
        if config.CUSTOMERS_JSON.exists():
            shutil.copy2(config.CUSTOMERS_JSON, backup_folder / "customers.json")

        return True, str(backup_folder)
    except Exception as e:
        return False, str(e)


def restore_data(backup_folder_path: str) -> Tuple[bool, str]:
    """Restores database from a selected backup folder."""
    try:
        folder = Path(backup_folder_path)
        if not folder.exists() or not folder.is_dir():
            return False, "Backup folder does not exist."

        backup_orders = folder / "orders.csv"
        backup_cust = folder / "customers.json"

        if backup_orders.exists():
            shutil.copy2(backup_orders, config.ORDERS_CSV)
        if backup_cust.exists():
            shutil.copy2(backup_cust, config.CUSTOMERS_JSON)

        return True, "Data restored successfully."
    except Exception as e:
        return False, str(e)


def list_backups() -> List[Path]:
    """Returns a list of all backup folders sorted newest first."""
    if not config.BACKUP_DIR.exists():
        return []
    folders = [f for f in config.BACKUP_DIR.iterdir() if f.is_dir() and f.name.startswith("backup_")]
    folders.sort(key=lambda x: x.name, reverse=True)
    return folders


def bulk_import_csv(csv_path: str) -> Tuple[int, int, List[str]]:
    """
    Imports orders from an external CSV file.
    Returns (imported_count, skipped_count, error_messages).
    """
    from modules.validation import (
        validate_customer_name,
        validate_mobile_number,
        validate_weight,
        validate_quantity,
        validate_price,
        validate_advance_payment
    )
    from modules.calculation import calculate_total_amount, calculate_pending_amount, determine_payment_status

    existing_orders = load_orders()
    existing_ids = {o["order_id"] for o in existing_orders}
    
    imported_count = 0
    skipped_count = 0
    errors: List[str] = []

    try:
        with open(csv_path, mode="r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for line_no, row in enumerate(reader, start=2):
                oid = str(row.get("order_id", "")).strip() or get_next_order_id(existing_orders)
                if oid in existing_ids:
                    skipped_count += 1
                    errors.append(f"Row {line_no}: Duplicate Order ID '{oid}' skipped.")
                    continue

                valid_name, name_val = validate_customer_name(row.get("customer_name", ""))
                if not valid_name:
                    skipped_count += 1
                    errors.append(f"Row {line_no}: Invalid name ({name_val})")
                    continue

                valid_phone, phone_val = validate_mobile_number(row.get("customer_phone", ""))
                if not valid_phone:
                    phone_val = "9876543210"  # default fallback if importing raw

                valid_w, weight_val, _ = validate_weight(row.get("weight_kg", 1.0))
                if not valid_w:
                    weight_val = 1.0

                valid_q, qty_val, _ = validate_quantity(row.get("quantity", 1))
                if not valid_q:
                    qty_val = 1

                _, price_val, _ = validate_price(row.get("price_per_kg", 600.0))
                _, extra_val, _ = validate_price(row.get("extra_charges", 0.0))

                total = calculate_total_amount(price_val, weight_val, qty_val, extra_val)
                _, advance_val, _ = validate_advance_payment(row.get("advance_paid", 0.0), total)
                pending = calculate_pending_amount(total, advance_val)
                pay_status = determine_payment_status(total, advance_val)

                new_order = {
                    "order_id": oid,
                    "customer_id": str(row.get("customer_id", "C001")).strip(),
                    "customer_name": name_val,
                    "customer_phone": phone_val,
                    "cake_type": str(row.get("cake_type", "Birthday Cake")).strip(),
                    "flavour": str(row.get("flavour", "Chocolate Truffle")).strip(),
                    "weight_kg": weight_val,
                    "quantity": qty_val,
                    "cake_message": str(row.get("cake_message", "")).strip(),
                    "price_per_kg": price_val,
                    "extra_charges": extra_val,
                    "total_amount": total,
                    "advance_paid": advance_val,
                    "pending_amount": pending,
                    "payment_status": pay_status,
                    "order_date": str(row.get("order_date", datetime.today().strftime("%Y-%m-%d"))).strip(),
                    "pickup_date": str(row.get("pickup_date", datetime.today().strftime("%Y-%m-%d"))).strip(),
                    "pickup_time": str(row.get("pickup_time", "18:00")).strip(),
                    "order_status": str(row.get("order_status", "Pending")).strip(),
                    "special_notes": str(row.get("special_notes", "")).strip(),
                }
                existing_orders.append(new_order)
                existing_ids.add(oid)
                imported_count += 1

        if imported_count > 0:
            save_orders(existing_orders)

    except Exception as e:
        errors.append(f"File reading error: {str(e)}")

    return imported_count, skipped_count, errors
