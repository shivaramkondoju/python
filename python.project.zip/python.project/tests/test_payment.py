"""Unit tests for price calculation and payment module."""

import unittest
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.calculation import (
    calculate_total_amount,
    calculate_pending_amount,
    determine_payment_status,
    calculate_cake_base_price
)


class TestPaymentAndCalculation(unittest.TestCase):

    def test_total_calculation_formula(self):
        # Formula: Total = (price_per_kg * weight * qty) + extra_charges
        # 600 * 2 * 1 + 100 = 1300
        total = calculate_total_amount(
            price_per_kg=600.0,
            weight_kg=2.0,
            quantity=1,
            extra_charges=100.0
        )
        self.assertEqual(total, 1300.0)

    def test_total_with_multiple_quantity(self):
        # 500 * 1.5 * 2 + 150 = 1650
        total = calculate_total_amount(
            price_per_kg=500.0,
            weight_kg=1.5,
            quantity=2,
            extra_charges=150.0
        )
        self.assertEqual(total, 1650.0)

    def test_pending_amount_calculation(self):
        # Pending = Total - Advance
        pending = calculate_pending_amount(total_amount=1300.0, advance_paid=500.0)
        self.assertEqual(pending, 800.0)

    def test_payment_status_fully_paid(self):
        status = determine_payment_status(total_amount=1300.0, advance_paid=1300.0)
        self.assertEqual(status, "Paid")

    def test_payment_status_partially_paid(self):
        status = determine_payment_status(total_amount=1300.0, advance_paid=500.0)
        self.assertEqual(status, "Partially Paid")

    def test_payment_status_pending_unpaid(self):
        status = determine_payment_status(total_amount=1300.0, advance_paid=0.0)
        self.assertEqual(status, "Pending")


if __name__ == "__main__":
    unittest.main()
