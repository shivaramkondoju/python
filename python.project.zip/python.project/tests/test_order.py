"""Unit tests for order registration and search module."""

import unittest
import sys
from pathlib import Path
from datetime import date, timedelta

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import storage.database as db
import modules.order as order_mod
import modules.search as search_mod


class TestOrderModule(unittest.TestCase):

    def setUp(self):
        # Backup original orders & customers in memory
        self.orig_orders = db.load_orders()
        self.orig_customers = db.load_customers()

    def tearDown(self):
        # Restore original state after tests
        db.save_orders(self.orig_orders)
        db.save_customers(self.orig_customers)

    def test_register_and_retrieve_order(self):
        future_date = (date.today() + timedelta(days=3)).strftime("%Y-%m-%d")
        success, order, msg = order_mod.register_new_order(
            customer_name="Test Customer",
            customer_phone="9876543210",
            cake_type="Birthday Cake",
            flavour="Chocolate Truffle",
            weight_kg=2.0,
            quantity=1,
            cake_message="Happy Birthday Test",
            price_per_kg=650.0,
            extra_charges=50.0,
            advance_paid=500.0,
            pickup_date_str=future_date,
            pickup_time_str="18:00"
        )
        self.assertTrue(success)
        self.assertIsNotNone(order)
        oid = order["order_id"]

        # Expected total: 650 * 2 * 1 + 50 = 1350
        self.assertEqual(order["total_amount"], 1350.0)
        self.assertEqual(order["advance_paid"], 500.0)
        self.assertEqual(order["pending_amount"], 850.0)
        self.assertEqual(order["payment_status"], "Partially Paid")

        # Fetch by ID
        fetched = order_mod.get_order_by_id(oid)
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched["customer_name"], "Test Customer")

    def test_search_orders(self):
        all_orders = order_mod.get_all_orders()
        # Search by non-existent query
        results = search_mod.search_orders(all_orders, query="NON_EXISTENT_QUERY_XYZ_123")
        self.assertEqual(len(results), 0)


if __name__ == "__main__":
    unittest.main()
