"""Unit tests for input validation module."""

import unittest
from datetime import date, timedelta
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.validation import (
    validate_customer_name,
    validate_mobile_number,
    validate_weight,
    validate_quantity,
    validate_price,
    validate_advance_payment,
    validate_date,
    validate_order_id
)


class TestValidation(unittest.TestCase):

    def test_customer_name_valid(self):
        valid, val = validate_customer_name("Rahul Sharma")
        self.assertTrue(valid)
        self.assertEqual(val, "Rahul Sharma")

    def test_customer_name_blank(self):
        valid, err = validate_customer_name("   ")
        self.assertFalse(valid)
        self.assertIn("cannot be empty", err)

    def test_customer_name_too_short(self):
        valid, err = validate_customer_name("A")
        self.assertFalse(valid)
        self.assertIn("at least 2 characters", err)

    def test_mobile_number_valid_10_digits(self):
        valid, val = validate_mobile_number("9876543210")
        self.assertTrue(valid)
        self.assertEqual(val, "9876543210")

    def test_mobile_number_with_country_code(self):
        valid, val = validate_mobile_number("+91 98765 43210")
        self.assertTrue(valid)
        self.assertEqual(val, "9876543210")

    def test_mobile_number_invalid_length(self):
        valid, err = validate_mobile_number("98765")
        self.assertFalse(valid)
        self.assertIn("exactly 10 digits", err)

    def test_mobile_number_invalid_start_digit(self):
        valid, err = validate_mobile_number("1234567890")
        self.assertFalse(valid)
        self.assertIn("start with 6, 7, 8, or 9", err)

    def test_cake_weight_positive(self):
        valid, val, _ = validate_weight("2.5")
        self.assertTrue(valid)
        self.assertEqual(val, 2.5)

    def test_cake_weight_zero_or_negative(self):
        valid_zero, _, err_zero = validate_weight("0")
        self.assertFalse(valid_zero)
        valid_neg, _, _ = validate_weight("-1.5")
        self.assertFalse(valid_neg)

    def test_quantity_positive_integer(self):
        valid, val, _ = validate_quantity("3")
        self.assertTrue(valid)
        self.assertEqual(val, 3)

    def test_quantity_negative_or_zero(self):
        v1, _, _ = validate_quantity("0")
        self.assertFalse(v1)
        v2, _, _ = validate_quantity("-2")
        self.assertFalse(v2)

    def test_price_non_negative(self):
        v1, val, _ = validate_price("650")
        self.assertTrue(v1)
        self.assertEqual(val, 650.0)

        v2, _, _ = validate_price("-50")
        self.assertFalse(v2)

    def test_advance_payment_valid_and_overpay_rejection(self):
        # Valid partial payment
        v1, val, _ = validate_advance_payment("500", 1200.0)
        self.assertTrue(v1)
        self.assertEqual(val, 500.0)

        # Advance exceeding total must be rejected
        v2, _, err2 = validate_advance_payment("1500", 1200.0)
        self.assertFalse(v2)
        self.assertIn("cannot exceed total amount", err2)

        # Negative advance must be rejected
        v3, _, _ = validate_advance_payment("-100", 1200.0)
        self.assertFalse(v3)

    def test_pickup_date_validation(self):
        today_str = date.today().strftime("%Y-%m-%d")
        v1, norm_d, _ = validate_date(today_str, allow_past=False)
        self.assertTrue(v1)

        past_date = (date.today() - timedelta(days=5)).strftime("%Y-%m-%d")
        v2, _, err = validate_date(past_date, allow_past=False)
        self.assertFalse(v2)

    def test_order_id_uniqueness(self):
        existing = ["B001", "B002", "B003"]
        v1, res1 = validate_order_id("B004", existing)
        self.assertTrue(v1)
        self.assertEqual(res1, "B004")

        v2, err2 = validate_order_id("B002", existing)
        self.assertFalse(v2)
        self.assertIn("already exists", err2)


if __name__ == "__main__":
    unittest.main()
