"""Data Seeder for Bakery Order Register (Hackathon Project #87).

Populates storage with 50 realistic cake orders and customer profiles.
"""

import sys
from pathlib import Path
from datetime import date, timedelta

# Ensure project root is in python path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import config
import storage.database as db
from modules.calculation import calculate_total_amount, calculate_pending_amount, determine_payment_status

customers_data = [
    ('Rahul Sharma', '9876543210', 'Banjara Hills, Hyderabad'),
    ('Priya Patel', '9823456781', 'Jubilee Hills, Hyderabad'),
    ('Amit Verma', '9845123456', 'Madhapur, Hyderabad'),
    ('Sneha Reddy', '9988776655', 'Gachibowli, Hyderabad'),
    ('Rajesh Kumar', '9712345678', 'Kondapur, Hyderabad'),
    ('Ananya Iyer', '9890123456', 'Hitec City, Hyderabad'),
    ('Vikram Malhotra', '9765432109', 'Somajiguda, Hyderabad'),
    ('Pooja Gupta', '9833445566', 'Begumpet, Hyderabad'),
    ('Rohan Nair', '9944556677', 'Kukatpally, Hyderabad'),
    ('Neha Singh', '9811223344', 'Secunderabad'),
    ('Aditya Joshi', '9922334455', 'Ameerpet, Hyderabad'),
    ('Kavita Rao', '9877889900', 'Dilsukhnagar, Hyderabad'),
    ('Suresh Menon', '9744332211', 'Tarnaka, Secunderabad'),
    ('Deepa Sen', '9866554433', 'Manikonda, Hyderabad'),
    ('Karthik Venkatesh', '9955443322', 'Miyapur, Hyderabad'),
    ('Meera Mukherjee', '9812345670', 'Nallagandla, Hyderabad'),
    ('Sandeep Bansal', '9723456789', 'Sainikpuri, Secunderabad'),
    ('Ritu Aggarwal', '9834567890', 'Balanagar, Hyderabad'),
    ('Gaurav Kapoor', '9945678901', 'Mehdipatnam, Hyderabad'),
    ('Shweta Deshmukh', '9756789012', 'Himayatnagar, Hyderabad'),
    ('Arjun Mehta', '9867890123', 'Attapur, Hyderabad'),
    ('Divya Choudhary', '9978901234', 'Abids, Hyderabad'),
    ('Naveen Pillai', '9789012345', 'Kacheguda, Hyderabad'),
    ('Tanvi Saxena', '9890123457', 'Tolichowki, Hyderabad'),
    ('Manish Tiwari', '9901234568', 'Chandanagar, Hyderabad')
]

def seed_sample_data():
    customers_list = []
    cust_map = {}
    for i, (name, phone, addr) in enumerate(customers_data, 1):
        cid = f"C{i:03d}"
        clean_email = name.lower().replace(" ", ".") + "@gmail.com"
        c_dict = {
            "customer_id": cid,
            "name": name,
            "phone": phone,
            "address": addr,
            "email": clean_email,
            "total_orders": 0,
            "created_at": "2026-11-01 10:00:00"
        }
        customers_list.append(c_dict)
        cust_map[phone] = c_dict

    flavours = list(config.FLAVOUR_BASE_PRICES.keys())
    types = config.CAKE_TYPES
    weights = [1.0, 1.5, 2.0, 2.5, 3.0, 0.5, 1.0, 2.0, 1.0, 1.5]
    messages = [
        "Happy 25th Birthday!",
        "Happy Anniversary Mom & Dad",
        "Best Wishes on Your Promotion",
        "Happy Birthday Little Princess",
        "Congratulations on Graduation",
        "Sweetest Anniversary Ever",
        "Happy 1st Birthday Aarav",
        "Cheers to 50 Years",
        "Warmest Congratulations",
        "Welcome Home!",
        "Best Boss Ever",
        ""
    ]
    extras_options = [0.0, 0.0, 100.0, 150.0, 200.0, 250.0]

    orders = []
    base_date = date(2026, 11, 22)

    # Generate 50 realistic orders
    for i in range(1, 51):
        oid = f"B{i:03d}"
        cust = customers_data[(i - 1) % len(customers_data)]
        name, phone, addr = cust
        cid = cust_map[phone]["customer_id"]
        cust_map[phone]["total_orders"] += 1

        flav = flavours[(i * 3 + 2) % len(flavours)]
        ctype = types[(i * 2 + 1) % len(types)]
        wt = weights[(i * 7) % len(weights)]
        qty = 1 if i % 12 != 0 else 2
        rate = config.FLAVOUR_BASE_PRICES[flav]
        extra = extras_options[i % len(extras_options)]
        tot = calculate_total_amount(rate, wt, qty, extra)

        # Scenarios distribution:
        if i <= 28:
            # Completed historical orders (placed earlier in Nov, picked up before today)
            day_offset = -21 + (i % 20)
            o_date = base_date + timedelta(days=day_offset - 2)
            p_date = base_date + timedelta(days=day_offset)
            status = "Completed"
            adv = tot  # Fully paid on completion
        elif i in (29, 30):
            # Cancelled orders
            o_date = base_date - timedelta(days=5)
            p_date = base_date - timedelta(days=1)
            status = "Cancelled"
            adv = 0.0
        elif i in (31, 32):
            # Overdue orders (past date, not completed)
            o_date = base_date - timedelta(days=4)
            p_date = base_date - timedelta(days=1)
            status = "Preparing"
            adv = round(tot * 0.4, 2)
        elif i in (33, 34, 35):
            # Pickups scheduled for TODAY (2026-11-22)
            o_date = base_date - timedelta(days=2)
            p_date = base_date
            status = "Ready for Pickup"
            adv = round(tot * 0.5, 2) if i != 33 else tot
        elif i in (36, 37, 38, 39, 40):
            # Tomorrow and near upcoming pickups (Nov 23-24)
            o_date = base_date - timedelta(days=1)
            p_date = base_date + timedelta(days=(i % 3) + 1)
            status = "Preparing" if i % 2 == 0 else "Pending"
            adv = round(tot * 0.5, 2)
        else:
            # Later upcoming (Nov 25-29)
            o_date = base_date
            p_date = base_date + timedelta(days=(i - 40) + 2)
            status = "Pending"
            adv = 0.0 if i % 3 == 0 else round(tot * 0.3, 2)

        pnd = calculate_pending_amount(tot, adv)
        pay_st = determine_payment_status(tot, adv)
        msg = messages[i % len(messages)]
        notes = "Eggless preparation requested" if i % 4 == 0 else ("Less sugar requested" if i % 5 == 0 else "")

        order_dict = {
            "order_id": oid,
            "customer_id": cid,
            "customer_name": name,
            "customer_phone": phone,
            "cake_type": ctype,
            "flavour": flav,
            "weight_kg": wt,
            "quantity": qty,
            "cake_message": msg,
            "price_per_kg": rate,
            "extra_charges": extra,
            "total_amount": tot,
            "advance_paid": adv,
            "pending_amount": pnd,
            "payment_status": pay_st,
            "order_date": o_date.strftime("%Y-%m-%d"),
            "pickup_date": p_date.strftime("%Y-%m-%d"),
            "pickup_time": f"{14 + (i % 6):02d}:00",
            "order_status": status,
            "special_notes": notes
        }
        orders.append(order_dict)

    db.save_orders(orders)
    db.save_customers(customers_list)
    print(f"[+] Successfully seeded {len(orders)} orders into orders.csv")
    print(f"[+] Successfully seeded {len(customers_list)} customers into customers.json")

if __name__ == "__main__":
    seed_sample_data()
