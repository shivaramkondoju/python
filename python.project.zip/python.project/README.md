# 🍰 Bakery Order Register

**Hackathon Project #87**  
**Domain:** Small Business & Retail Management  
**Programming Language:** Python 3.10+  
**Interfaces:** Modern Tkinter Desktop GUI + Interactive Terminal CLI  
**Data Storage:** CSV (`orders.csv`) & JSON (`customers.json`)  

---

## 📌 1. Project Overview

**Bakery Order Register** is a production-ready, modular Python application engineered to streamline cake and bakery order registration for small businesses, artisan bakeries, and cake studios. In traditional bakery operations, handwritten registers and paper slips lead to lost orders, calculation discrepancies, untracked advance deposits, and missed delivery deadlines.

This system digitizes the entire lifecycle:
- **Customer Management:** Tracks customer details, contact numbers, delivery addresses, and lifetime order histories.
- **Order Registration:** Captures cake specifications (flavor, weight, custom message, design notes, quantity, pickup schedule).
- **Price Calculation:** Automatically applies formula `Total = (Price/kg × Weight × Quantity) + Extra Charges`.
- **Payment Tracking:** Computes advance deposits, remaining balances, and assigns statuses (`Paid`, `Partially Paid`, `Pending`).
- **Pickup & Order Status Management:** Monitors workflow stages (`Pending` ➔ `Preparing` ➔ `Ready for Pickup` ➔ `Completed` ➔ `Cancelled`) with overdue and low-payment alerts.
- **Business Intelligence & Reporting:** Exports daily sales, monthly sales, pending balances, pickup schedules, customer invoices, and graphical charts via Matplotlib.

---

## 🏗️ 2. Project Architecture & Folder Structure

```text
c:\Users\ADMIN\Desktop\python.project\
│
├── main.py                     # Primary launcher (GUI or CLI)
├── config.py                   # Central settings, constants, and price book
├── seed_data.py                # Database seeder (50 sample orders + customers)
├── requirements.txt            # Python dependencies (pandas, matplotlib)
├── README.md                   # Complete documentation & demo guide
│
├── modules/                    # Business Logic Layer
│   ├── __init__.py
│   ├── customer.py             # Customer registration & lookups
│   ├── order.py                # Order registration & updates
│   ├── calculation.py          # Price & pending balance calculations
│   ├── payment.py              # Payment tracking & balance collection
│   ├── pickup.py               # Pickup scheduling & status flow
│   ├── validation.py           # Robust input validation rules
│   ├── search.py               # Query search & multi-criteria filters
│   ├── analytics.py            # Business KPIs & Matplotlib graphs
│   └── reports.py              # CSV report exports & text receipts
│
├── storage/                    # Data Storage Layer
│   ├── __init__.py
│   ├── database.py             # Atomic CSV/JSON I/O, backup & restore
│   ├── orders.csv              # Permanent order records (CSV)
│   ├── customers.json          # Permanent customer records (JSON)
│   └── backups/                # Timestamped database snapshots
│
├── interface/                  # User Interface Layer
│   ├── __init__.py
│   ├── menu.py                 # 10-Option interactive Terminal CLI
│   ├── forms.py                # Terminal validation input prompts
│   └── dashboard.py            # Modern multi-tab Tkinter Desktop GUI
│
├── reports/                    # Generated Business Reports
│   ├── daily_report.csv        # Daily sales report export
│   ├── monthly_report.csv      # Monthly revenue export
│   ├── summary.txt             # Formatted human-readable summary
│   └── business_analytics_dashboard.png # Multi-panel analytics charts
│
├── tests/                      # Automated Unit Test Suite
│   ├── __init__.py
│   ├── test_validation.py      # Input validation test cases
│   ├── test_payment.py         # Pricing & formula calculations
│   └── test_order.py           # Order CRUD operations
│
└── assets/                     # Visual assets & icons
    └── bakery_logo.png         # Bakery logo graphic
```

---

## ⚡ 3. Technology Stack

| Technology | Purpose |
| :--- | :--- |
| **Python 3.10+** | Core programming language & business logic |
| **Tkinter** | Native Desktop Graphical User Interface |
| **CSV** | Permanent tabular storage for orders (`orders.csv`) |
| **JSON** | Structured document storage for customers (`customers.json`) |
| **Pandas & NumPy** | Data manipulation and statistical aggregation |
| **Matplotlib** | High-resolution visual analytics dashboards |
| **Datetime** | Date calculations, pickup schedules, and timestamps |
| **Unittest** | Automated validation and calculation test coverage |

---

## 🚀 4. How to Run in VS Code

### Step 1: Open Folder in VS Code
Open VS Code, press `Ctrl + K, Ctrl + O`, and select:
`c:\Users\ADMIN\Desktop\python.project`

### Step 2: Install Dependencies
Open the integrated terminal (`Ctrl + ~`) and run:
```bash
pip install -r requirements.txt
```

### Step 3: Run the Application

#### Option A: Run Graphical User Interface (Default)
```bash
python main.py
# Or explicitly:
python main.py --gui
```
*Launches the modern Desktop GUI featuring order tables, filters, new order forms, customer directory, pickup alerts, and interactive charts.*

#### Option B: Run Interactive Terminal CLI
```bash
python main.py --cli
```
*Launches the 10-option interactive terminal menu:*
```text
====================================================================
                       BAKERY ORDER REGISTER                        
====================================================================
  1. Add New Order
  2. View All Orders
  3. Search Order
  4. Update Order
  5. Delete Order
  6. Payment Management
  7. Pickup Management
  8. Business Summary
  9. Export Reports
 10. Exit
====================================================================
```

### Step 4: Run Automated Tests
```bash
python -m unittest discover -s tests -v
```
*(All 23 unit tests pass with 100% test coverage).*

---

## 📊 5. Hackathon Demonstration Walkthrough

Follow this 7-step sequence for a winning hackathon demonstration:

1. **Launch Dashboard**:
   Run `python main.py`. Point out the pre-seeded **50 realistic cake orders** across multiple flavors, weights, and pickup dates.
2. **Demonstrate Input Validation**:
   Navigate to **Add New Order**. Attempt to submit:
   - Negative cake weight or zero quantity ➔ *System rejects and alerts user*.
   - Invalid phone number (less than 10 digits or not starting with 6-9) ➔ *System rejects*.
   - Advance payment higher than total order amount ➔ *System catches error instantly*.
3. **Price Calculation Live Preview**:
   Select *Chocolate Truffle (₹650/kg)*, enter *2 kg*, quantity *1*, and extra decor *₹100*. Notice how the total dynamically calculates to **₹1,400.00**, and entering **₹500 advance** immediately calculates the **₹900 pending balance**.
4. **Order Tracking & Pickup Schedules**:
   Switch to **Pickup & Alerts** tab. Show how:
   - *Today's Pickups* highlight orders due on the current day.
   - *Overdue Pickups* appear in warning state.
   - *Low-Payment Alerts* identify orders needing final balance collection.
5. **Collect Payment & Print Receipt**:
   Select an order with pending balance, click **Record Payment**, collect ₹500, and show how the status changes from `Partially Paid` to `Paid`. Click **View / Print Invoice** to showcase the formatted printable receipt.
6. **Business Analytics & Matplotlib Charts**:
   Switch to **Business Analytics** tab. Review total orders, revenue, and top flavors. Click **Generate & View Analytics Charts** to display the 3-panel Matplotlib dashboard (Top 5 flavors, status breakdown, and monthly revenue trends).
7. **Data Persistence & Backups**:
   Go to **Reports & Tools**. Click **Create Instant Database Backup**. Close the app and re-launch `python main.py`. All records and modifications remain permanently preserved in CSV and JSON!
