"""Search and Filtering Module for Bakery Order Register."""

from datetime import datetime
from typing import List, Dict, Any, Optional

import storage.database as db
from modules.validation import sanitize_string


def search_orders(
    orders: Optional[List[Dict[str, Any]]] = None,
    query: Optional[str] = None,
    order_status: Optional[str] = None,
    payment_status: Optional[str] = None,
    cake_type: Optional[str] = None,
    flavour: Optional[str] = None,
    pickup_date: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Searches and filters orders based on multiple criteria.
    - query: matches order_id, customer_name, customer_phone, or cake_message.
    - order_status: exact match for status (e.g. 'Pending', 'Preparing').
    - payment_status: exact match for payment status ('Paid', 'Partially Paid', 'Pending').
    - cake_type: matches cake type.
    - flavour: matches flavour.
    - pickup_date: matches exact pickup date (YYYY-MM-DD).
    - start_date / end_date: matches pickup date range.
    """
    if orders is None:
        orders = db.load_orders()

    filtered = list(orders)

    # General text query (ID, Name, Phone, Message)
    if query:
        q = sanitize_string(query).lower()
        filtered = [
            o for o in filtered
            if q in str(o.get("order_id", "")).lower()
            or q in str(o.get("customer_name", "")).lower()
            or q in str(o.get("customer_phone", "")).lower()
            or q in str(o.get("cake_message", "")).lower()
            or q in str(o.get("flavour", "")).lower()
        ]

    # Status filters
    if order_status and order_status != "All":
        clean_status = sanitize_string(order_status).lower()
        filtered = [o for o in filtered if str(o.get("order_status", "")).lower() == clean_status]

    if payment_status and payment_status != "All":
        clean_pay = sanitize_string(payment_status).lower()
        filtered = [o for o in filtered if str(o.get("payment_status", "")).lower() == clean_pay]

    if cake_type and cake_type != "All":
        ct = sanitize_string(cake_type).lower()
        filtered = [o for o in filtered if ct in str(o.get("cake_type", "")).lower()]

    if flavour and flavour != "All":
        fl = sanitize_string(flavour).lower()
        filtered = [o for o in filtered if fl in str(o.get("flavour", "")).lower()]

    # Specific date filter
    if pickup_date:
        p_clean = sanitize_string(pickup_date)
        filtered = [o for o in filtered if str(o.get("pickup_date", "")) == p_clean]

    # Date range filter
    if start_date or end_date:
        range_results = []
        for o in filtered:
            p_str = o.get("pickup_date", "")
            try:
                p_dt = datetime.strptime(p_str, "%Y-%m-%d").date()
                if start_date:
                    s_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
                    if p_dt < s_dt:
                        continue
                if end_date:
                    e_dt = datetime.strptime(end_date, "%Y-%m-%d").date()
                    if p_dt > e_dt:
                        continue
                range_results.append(o)
            except ValueError:
                continue
        filtered = range_results

    return filtered
