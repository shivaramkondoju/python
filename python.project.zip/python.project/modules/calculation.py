"""Price and Payment Calculation Module for Bakery Order Register."""

from typing import Tuple


def calculate_cake_base_price(price_per_kg: float, weight_kg: float, quantity: int = 1) -> float:
    """Calculates the base price of the cake."""
    return round(float(price_per_kg) * float(weight_kg) * int(quantity), 2)


def calculate_total_amount(
    price_per_kg: float,
    weight_kg: float,
    quantity: int = 1,
    extra_charges: float = 0.0
) -> float:
    """
    Calculates total amount based on:
    Total Amount = (Price per kg * Weight * Quantity) + Extra Charges
    """
    base = calculate_cake_base_price(price_per_kg, weight_kg, quantity)
    total = base + float(extra_charges)
    return round(total, 2)


def calculate_pending_amount(total_amount: float, advance_paid: float) -> float:
    """
    Calculates remaining pending balance:
    Pending Amount = Total Amount - Advance Payment
    """
    pending = float(total_amount) - float(advance_paid)
    # Avoid negative floating point precision quirks like -0.0
    return max(0.0, round(pending, 2))


def determine_payment_status(total_amount: float, advance_paid: float) -> str:
    """
    Determines payment status according to amount paid:
    - Paid: Full payment completed (advance_paid >= total_amount)
    - Partially Paid: Some amount received (0 < advance_paid < total_amount)
    - Pending: No payment received (advance_paid <= 0)
    """
    total = round(float(total_amount), 2)
    paid = round(float(advance_paid), 2)
    
    if total <= 0:
        return "Paid"
    
    if paid >= total:
        return "Paid"
    elif paid > 0:
        return "Partially Paid"
    else:
        return "Pending"


def recalculate_order_pricing(order_data: dict) -> dict:
    """
    Helper function to recalculate total, pending, and payment status for an order dict.
    Returns the updated order_data dictionary.
    """
    price_per_kg = float(order_data.get("price_per_kg", 0.0))
    weight_kg = float(order_data.get("weight_kg", 1.0))
    quantity = int(order_data.get("quantity", 1))
    extra_charges = float(order_data.get("extra_charges", 0.0))
    advance_paid = float(order_data.get("advance_paid", 0.0))

    total = calculate_total_amount(price_per_kg, weight_kg, quantity, extra_charges)
    pending = calculate_pending_amount(total, advance_paid)
    status = determine_payment_status(total, advance_paid)

    order_data["total_amount"] = total
    order_data["pending_amount"] = pending
    order_data["payment_status"] = status
    return order_data
