"""Order Registration and Management Module for Bakery Order Register."""

from datetime import datetime, date
from typing import List, Dict, Any, Optional, Tuple

import config
import storage.database as db
from modules.customer import get_or_create_customer, increment_customer_orders
from modules.calculation import calculate_total_amount, calculate_pending_amount, determine_payment_status
from modules.validation import (
    validate_customer_name,
    validate_mobile_number,
    validate_weight,
    validate_quantity,
    validate_price,
    validate_advance_payment,
    validate_date,
    validate_order_id,
    sanitize_string
)


def get_all_orders() -> List[Dict[str, Any]]:
    """Retrieves all orders from storage."""
    return db.load_orders()


def get_order_by_id(order_id: str, orders: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Fetches an order by its unique Order ID."""
    if orders is None:
        orders = db.load_orders()
    clean_id = sanitize_string(order_id).upper()
    for o in orders:
        if o.get("order_id", "").upper() == clean_id:
            return o
    return None


def register_new_order(
    customer_name: str,
    customer_phone: str,
    cake_type: str,
    flavour: str,
    weight_kg: float,
    quantity: int = 1,
    cake_message: str = "",
    price_per_kg: Optional[float] = None,
    extra_charges: float = 0.0,
    advance_paid: float = 0.0,
    pickup_date_str: str = "",
    pickup_time_str: str = "18:00",
    order_status: str = "Pending",
    special_notes: str = "",
    customer_address: str = "",
    custom_order_id: Optional[str] = None
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Validates and registers a new bakery cake order.
    Returns (success, order_dict, message).
    """
    orders = db.load_orders()
    existing_ids = [o["order_id"] for o in orders]

    # Validate Customer Details
    valid_name, clean_name = validate_customer_name(customer_name)
    if not valid_name:
        return False, None, clean_name

    valid_phone, clean_phone = validate_mobile_number(customer_phone)
    if not valid_phone:
        return False, None, clean_phone

    # Validate Weight and Quantity
    valid_w, weight_val, w_err = validate_weight(weight_kg)
    if not valid_w:
        return False, None, w_err

    valid_q, qty_val, q_err = validate_quantity(quantity)
    if not valid_q:
        return False, None, q_err

    # Determine Price per kg if not specified
    if price_per_kg is None or float(price_per_kg) <= 0:
        price_per_kg = config.FLAVOUR_BASE_PRICES.get(flavour, 600.0)

    valid_p, price_val, p_err = validate_price(price_per_kg, allow_zero=False)
    if not valid_p:
        return False, None, p_err

    valid_ex, extra_val, ex_err = validate_price(extra_charges, allow_zero=True)
    if not valid_ex:
        return False, None, ex_err

    # Calculations
    total_amount = calculate_total_amount(price_val, weight_val, qty_val, extra_val)

    valid_adv, advance_val, adv_err = validate_advance_payment(advance_paid, total_amount)
    if not valid_adv:
        return False, None, adv_err

    pending_amount = calculate_pending_amount(total_amount, advance_val)
    payment_status = determine_payment_status(total_amount, advance_val)

    # Validate Dates
    today_str = date.today().strftime("%Y-%m-%d")
    order_date_str = today_str

    if not pickup_date_str:
        pickup_date_str = today_str

    valid_pick, norm_pickup, pick_err = validate_date(pickup_date_str, allow_past=False)
    if not valid_pick:
        return False, None, f"Pickup Date error: {pick_err}"

    # Generate or validate Order ID
    if custom_order_id:
        valid_oid, oid_res = validate_order_id(custom_order_id, existing_ids)
        if not valid_oid:
            return False, None, oid_res
        order_id = oid_res
    else:
        order_id = db.get_next_order_id(orders)

    # Get or create customer profile in JSON
    _, cust, _ = get_or_create_customer(clean_name, clean_phone, customer_address)
    customer_id = cust.get("customer_id", "C001")

    # Order Status check
    clean_status = sanitize_string(order_status)
    if clean_status not in config.ORDER_STATUSES:
        clean_status = "Pending"

    new_order = {
        "order_id": order_id,
        "customer_id": customer_id,
        "customer_name": clean_name,
        "customer_phone": clean_phone,
        "cake_type": sanitize_string(cake_type) or "Birthday Cake",
        "flavour": sanitize_string(flavour) or "Chocolate Truffle",
        "weight_kg": weight_val,
        "quantity": qty_val,
        "cake_message": sanitize_string(cake_message),
        "price_per_kg": price_val,
        "extra_charges": extra_val,
        "total_amount": total_amount,
        "advance_paid": advance_val,
        "pending_amount": pending_amount,
        "payment_status": payment_status,
        "order_date": order_date_str,
        "pickup_date": norm_pickup,
        "pickup_time": sanitize_string(pickup_time_str) or "18:00",
        "order_status": clean_status,
        "special_notes": sanitize_string(special_notes)
    }

    orders.append(new_order)
    db.save_orders(orders)
    increment_customer_orders(customer_id)

    return True, new_order, f"Order {order_id} created successfully for {clean_name}!"


def update_existing_order(
    order_id: str,
    updates: Dict[str, Any]
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Updates an existing order record with validation.
    Returns (success, updated_order_dict, message).
    """
    orders = db.load_orders()
    clean_id = sanitize_string(order_id).upper()
    target_idx = None

    for i, o in enumerate(orders):
        if o.get("order_id", "").upper() == clean_id:
            target_idx = i
            break

    if target_idx is None:
        return False, None, f"Order ID '{clean_id}' not found."

    order = orders[target_idx]

    # Apply updates with validation
    if "customer_name" in updates:
        v, val = validate_customer_name(updates["customer_name"])
        if not v:
            return False, None, val
        order["customer_name"] = val

    if "customer_phone" in updates:
        v, val = validate_mobile_number(updates["customer_phone"])
        if not v:
            return False, None, val
        order["customer_phone"] = val

    if "weight_kg" in updates:
        v, val, err = validate_weight(updates["weight_kg"])
        if not v:
            return False, None, err
        order["weight_kg"] = val

    if "quantity" in updates:
        v, val, err = validate_quantity(updates["quantity"])
        if not v:
            return False, None, err
        order["quantity"] = val

    if "price_per_kg" in updates:
        v, val, err = validate_price(updates["price_per_kg"], allow_zero=False)
        if not v:
            return False, None, err
        order["price_per_kg"] = val

    if "extra_charges" in updates:
        v, val, err = validate_price(updates["extra_charges"], allow_zero=True)
        if not v:
            return False, None, err
        order["extra_charges"] = val

    # Recalculate total amount if weight, qty, price, or extra changed
    total = calculate_total_amount(
        order["price_per_kg"],
        order["weight_kg"],
        order["quantity"],
        order["extra_charges"]
    )
    order["total_amount"] = total

    if "advance_paid" in updates:
        v, val, err = validate_advance_payment(updates["advance_paid"], total)
        if not v:
            return False, None, err
        order["advance_paid"] = val

    order["pending_amount"] = calculate_pending_amount(order["total_amount"], order["advance_paid"])
    order["payment_status"] = determine_payment_status(order["total_amount"], order["advance_paid"])

    if "cake_type" in updates and updates["cake_type"]:
        order["cake_type"] = sanitize_string(updates["cake_type"])
    if "flavour" in updates and updates["flavour"]:
        order["flavour"] = sanitize_string(updates["flavour"])
    if "cake_message" in updates:
        order["cake_message"] = sanitize_string(updates["cake_message"])
    if "pickup_date" in updates and updates["pickup_date"]:
        v, val, err = validate_date(updates["pickup_date"], allow_past=True)
        if not v:
            return False, None, f"Pickup date error: {err}"
        order["pickup_date"] = val
    if "pickup_time" in updates:
        order["pickup_time"] = sanitize_string(updates["pickup_time"])
    if "order_status" in updates and updates["order_status"]:
        st = sanitize_string(updates["order_status"])
        if st in config.ORDER_STATUSES:
            order["order_status"] = st
    if "special_notes" in updates:
        order["special_notes"] = sanitize_string(updates["special_notes"])

    orders[target_idx] = order
    db.save_orders(orders)
    return True, order, f"Order {clean_id} updated successfully."


def delete_order(order_id: str) -> Tuple[bool, str]:
    """Deletes an order by ID."""
    orders = db.load_orders()
    clean_id = sanitize_string(order_id).upper()
    initial_len = len(orders)
    orders = [o for o in orders if o.get("order_id", "").upper() != clean_id]

    if len(orders) == initial_len:
        return False, f"Order ID '{clean_id}' not found."

    db.save_orders(orders)
    return True, f"Order '{clean_id}' deleted successfully."
