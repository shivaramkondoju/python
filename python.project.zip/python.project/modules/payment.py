"""Payment Management Module for Bakery Order Register."""

from typing import List, Dict, Any, Tuple, Optional

import storage.database as db
from modules.calculation import calculate_pending_amount, determine_payment_status
from modules.validation import validate_price, sanitize_string


def record_additional_payment(
    order_id: str,
    amount_paid: float
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Records an additional payment toward an order.
    Validates that payment does not exceed current pending amount.
    Returns (success, updated_order, message).
    """
    valid_p, clean_amount, err = validate_price(amount_paid, allow_zero=False)
    if not valid_p:
        return False, None, err

    orders = db.load_orders()
    clean_id = sanitize_string(order_id).upper()
    target_idx = None

    for i, o in enumerate(orders):
        if o.get("order_id", "").upper() == clean_id:
            target_idx = i
            break

    if target_idx is None:
        return False, None, f"Order ID '{clean_id}' not found."

    order = orders[target_idx]
    current_advance = float(order.get("advance_paid", 0.0))
    total_amount = float(order.get("total_amount", 0.0))
    current_pending = float(order.get("pending_amount", 0.0))

    if current_pending <= 0:
        return False, order, f"Order {clean_id} is already fully paid!"

    if round(clean_amount, 2) > round(current_pending, 2):
        return False, None, f"Payment (₹{clean_amount:.2f}) exceeds pending balance (₹{current_pending:.2f})."

    new_advance = round(current_advance + clean_amount, 2)
    new_pending = calculate_pending_amount(total_amount, new_advance)
    new_status = determine_payment_status(total_amount, new_advance)

    order["advance_paid"] = new_advance
    order["pending_amount"] = new_pending
    order["payment_status"] = new_status

    orders[target_idx] = order
    db.save_orders(orders)

    return True, order, f"Recorded ₹{clean_amount:.2f} payment for {clean_id}. Remaining balance: ₹{new_pending:.2f} ({new_status})."


def get_pending_payment_orders(orders: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """Returns orders that have pending or partial payments."""
    if orders is None:
        orders = db.load_orders()
    return [o for o in orders if float(o.get("pending_amount", 0.0)) > 0 and o.get("order_status") != "Cancelled"]


def get_low_payment_alerts(orders: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """
    Returns active orders where pending balance is high or payment is completely unpaid.
    Used for bakery dashboard alerts.
    """
    if orders is None:
        orders = db.load_orders()
    alerts = []
    for o in orders:
        if o.get("order_status") in ["Pending", "Preparing", "Ready for Pickup"]:
            if o.get("payment_status") in ["Pending", "Partially Paid"]:
                alerts.append(o)
    return alerts


def get_payment_summary(orders: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Generates overall payment figures across all orders."""
    if orders is None:
        orders = db.load_orders()

    total_order_value = 0.0
    total_advance_collected = 0.0
    total_pending_amount = 0.0

    status_counts = {"Paid": 0, "Partially Paid": 0, "Pending": 0}

    for o in orders:
        if o.get("order_status") == "Cancelled":
            continue
        tot = float(o.get("total_amount", 0.0))
        adv = float(o.get("advance_paid", 0.0))
        pnd = float(o.get("pending_amount", 0.0))
        st = o.get("payment_status", "Pending")

        total_order_value += tot
        total_advance_collected += adv
        total_pending_amount += pnd

        if st in status_counts:
            status_counts[st] += 1

    return {
        "total_order_value": round(total_order_value, 2),
        "total_collected": round(total_advance_collected, 2),
        "total_pending": round(total_pending_amount, 2),
        "status_counts": status_counts
    }
