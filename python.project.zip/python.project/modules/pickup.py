"""Pickup Date and Order Status Management Module for Bakery Order Register."""

from datetime import datetime, date, timedelta
from typing import List, Dict, Any, Tuple, Optional

import config
import storage.database as db
from modules.validation import sanitize_string


def get_todays_pickups(orders: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """Returns all non-completed/non-cancelled orders scheduled for pickup today."""
    if orders is None:
        orders = db.load_orders()
    today_str = date.today().strftime("%Y-%m-%d")
    return [
        o for o in orders
        if o.get("pickup_date") == today_str and o.get("order_status") not in ["Completed", "Cancelled"]
    ]


def get_upcoming_pickups(days: int = 7, orders: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """
    Returns upcoming orders scheduled for pickup within the next N days.
    """
    if orders is None:
        orders = db.load_orders()
    today = date.today()
    max_date = today + timedelta(days=days)

    upcoming = []
    for o in orders:
        if o.get("order_status") in ["Completed", "Cancelled"]:
            continue
        try:
            p_date = datetime.strptime(o.get("pickup_date", ""), "%Y-%m-%d").date()
            if today <= p_date <= max_date:
                upcoming.append(o)
        except ValueError:
            continue

    upcoming.sort(key=lambda x: (x.get("pickup_date", ""), x.get("pickup_time", "")))
    return upcoming


def get_overdue_pickups(orders: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """
    Returns orders where pickup date has passed but order is still not Completed or Cancelled.
    """
    if orders is None:
        orders = db.load_orders()
    today = date.today()
    overdue = []

    for o in orders:
        if o.get("order_status") in ["Completed", "Cancelled"]:
            continue
        try:
            p_date = datetime.strptime(o.get("pickup_date", ""), "%Y-%m-%d").date()
            if p_date < today:
                overdue.append(o)
        except ValueError:
            continue

    overdue.sort(key=lambda x: x.get("pickup_date", ""))
    return overdue


def update_order_status(
    order_id: str,
    new_status: str
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Updates status of an order (Pending, Preparing, Ready for Pickup, Completed, Cancelled).
    """
    clean_id = sanitize_string(order_id).upper()
    status_clean = sanitize_string(new_status)

    if status_clean not in config.ORDER_STATUSES:
        return False, None, f"Invalid status '{new_status}'. Allowed: {', '.join(config.ORDER_STATUSES)}"

    orders = db.load_orders()
    target_idx = None
    for i, o in enumerate(orders):
        if o.get("order_id", "").upper() == clean_id:
            target_idx = i
            break

    if target_idx is None:
        return False, None, f"Order ID '{clean_id}' not found."

    order = orders[target_idx]
    old_status = order.get("order_status")
    order["order_status"] = status_clean

    orders[target_idx] = order
    db.save_orders(orders)

    return True, order, f"Order {clean_id} status updated from '{old_status}' to '{status_clean}'."
