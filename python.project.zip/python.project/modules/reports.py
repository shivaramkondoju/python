"""Report Generation and Export Module for Bakery Order Register."""

import csv
from datetime import datetime, date
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import config
import storage.database as db
from modules.analytics import get_business_summary


def export_all_orders_csv(export_path: Optional[str] = None) -> Tuple[bool, str]:
    """Exports all current orders to a clean CSV file."""
    if not export_path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_path = str(config.REPORTS_DIR / f"all_orders_export_{timestamp}.csv")

    orders = db.load_orders()
    try:
        with open(export_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_FIELDNAMES)
            writer.writeheader()
            for o in orders:
                writer.writerow(o)
        return True, export_path
    except Exception as e:
        return False, str(e)


def generate_daily_sales_report(
    target_date: Optional[str] = None,
    export_path: Optional[str] = None
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Generates a daily sales CSV report for a given order date (default today).
    """
    if not target_date:
        target_date = date.today().strftime("%Y-%m-%d")

    if not export_path:
        export_path = str(config.REPORTS_DIR / f"daily_report_{target_date}.csv")

    orders = db.load_orders()
    daily_orders = [o for o in orders if o.get("order_date") == target_date]

    total_sales = sum(float(o.get("total_amount", 0.0)) for o in daily_orders if o.get("order_status") != "Cancelled")
    total_advance = sum(float(o.get("advance_paid", 0.0)) for o in daily_orders if o.get("order_status") != "Cancelled")
    total_pending = sum(float(o.get("pending_amount", 0.0)) for o in daily_orders if o.get("order_status") != "Cancelled")

    summary_stats = {
        "date": target_date,
        "count": len(daily_orders),
        "total_sales": round(total_sales, 2),
        "total_advance": round(total_advance, 2),
        "total_pending": round(total_pending, 2)
    }

    try:
        with open(export_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_FIELDNAMES)
            writer.writeheader()
            for o in daily_orders:
                writer.writerow(o)
        return True, export_path, summary_stats
    except Exception as e:
        return False, str(e), summary_stats


def generate_monthly_sales_report(
    year_month: Optional[str] = None,
    export_path: Optional[str] = None
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Generates a monthly sales CSV report for a given month 'YYYY-MM' (default current month).
    """
    if not year_month:
        year_month = date.today().strftime("%Y-%m")

    if not export_path:
        export_path = str(config.REPORTS_DIR / f"monthly_report_{year_month}.csv")

    orders = db.load_orders()
    monthly_orders = [o for o in orders if str(o.get("order_date", "")).startswith(year_month)]

    total_sales = sum(float(o.get("total_amount", 0.0)) for o in monthly_orders if o.get("order_status") != "Cancelled")
    total_advance = sum(float(o.get("advance_paid", 0.0)) for o in monthly_orders if o.get("order_status") != "Cancelled")
    total_pending = sum(float(o.get("pending_amount", 0.0)) for o in monthly_orders if o.get("order_status") != "Cancelled")

    stats = {
        "month": year_month,
        "count": len(monthly_orders),
        "total_sales": round(total_sales, 2),
        "total_advance": round(total_advance, 2),
        "total_pending": round(total_pending, 2)
    }

    try:
        with open(export_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_FIELDNAMES)
            writer.writeheader()
            for o in monthly_orders:
                writer.writerow(o)
        return True, export_path, stats
    except Exception as e:
        return False, str(e), stats


def generate_pending_payments_report(export_path: Optional[str] = None) -> Tuple[bool, str]:
    """Generates a dedicated CSV report of all unpaid and partially paid orders."""
    if not export_path:
        export_path = str(config.REPORTS_DIR / "pending_payments_report.csv")

    orders = db.load_orders()
    pending_orders = [
        o for o in orders
        if float(o.get("pending_amount", 0.0)) > 0 and o.get("order_status") != "Cancelled"
    ]

    try:
        fields = ["order_id", "customer_name", "customer_phone", "flavour", "total_amount", "advance_paid", "pending_amount", "pickup_date", "order_status"]
        with open(export_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for o in pending_orders:
                row = {k: o.get(k, "") for k in fields}
                writer.writerow(row)
        return True, export_path
    except Exception as e:
        return False, str(e)


def generate_pickup_schedule_report(export_path: Optional[str] = None) -> Tuple[bool, str]:
    """Generates a CSV schedule of all pending, preparing, and ready orders sorted by pickup date."""
    if not export_path:
        export_path = str(config.REPORTS_DIR / "pickup_schedule_report.csv")

    orders = db.load_orders()
    active_orders = [o for o in orders if o.get("order_status") in ["Pending", "Preparing", "Ready for Pickup"]]
    active_orders.sort(key=lambda x: (x.get("pickup_date", ""), x.get("pickup_time", "")))

    try:
        fields = ["pickup_date", "pickup_time", "order_id", "customer_name", "customer_phone", "cake_type", "flavour", "weight_kg", "cake_message", "order_status", "pending_amount"]
        with open(export_path, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for o in active_orders:
                row = {k: o.get(k, "") for k in fields}
                writer.writerow(row)
        return True, export_path
    except Exception as e:
        return False, str(e)


def generate_text_summary(export_path: Optional[str] = None) -> Tuple[bool, str, str]:
    """
    Generates a human-readable text summary of the bakery status and saves to summary.txt.
    """
    if not export_path:
        export_path = str(config.REPORTS_DIR / "summary.txt")

    summary = get_business_summary()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "=" * 60,
        f"        {config.BAKERY_INFO['name'].upper()}",
        f"             BUSINESS SUMMARY REPORT",
        f"               Generated: {now_str}",
        "=" * 60,
        f"Total Orders Registered   : {summary['total_orders']}",
        f"Completed Orders          : {summary['completed_orders']}",
        f"Active In-Progress Orders : {summary['active_orders']}",
        f"Cancelled Orders          : {summary['cancelled_orders']}",
        "-" * 60,
        f"Total Order Value / Sales : {config.BAKERY_INFO['currency_symbol']}{summary['total_revenue']:,.2f}",
        f"Total Advance Collected   : {config.BAKERY_INFO['currency_symbol']}{summary['total_collected']:,.2f}",
        f"Total Pending Payments    : {config.BAKERY_INFO['currency_symbol']}{summary['total_pending']:,.2f}",
        f"Average Order Value (AOV) : {config.BAKERY_INFO['currency_symbol']}{summary['average_order_value']:,.2f}",
        "-" * 60,
        "Order Status Distribution:",
    ]

    for st, count in summary['status_distribution'].items():
        lines.append(f"  - {st:<20}: {count} orders")

    lines.append("-" * 60)
    lines.append("Top 5 Customer Favorite Cake Flavours:")
    for flav, count in summary['popular_flavours']:
        lines.append(f"  * {flav:<22}: {count} orders")

    lines.append("=" * 60)
    text_content = "\n".join(lines)

    try:
        with open(export_path, mode="w", encoding="utf-8") as f:
            f.write(text_content)
        return True, export_path, text_content
    except Exception as e:
        return False, str(e), text_content


def generate_printable_invoice(order: Dict[str, Any], export_path: Optional[str] = None) -> Tuple[bool, str, str]:
    """
    Generates a beautifully formatted customer invoice receipt as a text file.
    """
    order_id = order.get("order_id", "UNKNOWN")
    if not export_path:
        export_path = str(config.REPORTS_DIR / f"invoice_{order_id}.txt")

    curr = config.BAKERY_INFO["currency_symbol"]
    weight = float(order.get("weight_kg", 1.0))
    qty = int(order.get("quantity", 1))
    price = float(order.get("price_per_kg", 0.0))
    base = round(price * weight * qty, 2)
    extra = float(order.get("extra_charges", 0.0))
    total = float(order.get("total_amount", 0.0))
    advance = float(order.get("advance_paid", 0.0))
    pending = float(order.get("pending_amount", 0.0))

    lines = [
        "*" * 62,
        f"         {config.BAKERY_INFO['name'].center(44)}",
        f"      {config.BAKERY_INFO['tagline'].center(48)}",
        f"  {config.BAKERY_INFO['address']}",
        f"  Phone: {config.BAKERY_INFO['phone']} | {config.BAKERY_INFO['fssai_lic']}",
        "*" * 62,
        f"  ORDER INVOICE / RECEIPT: #{order_id}",
        f"  Date: {order.get('order_date')} | Time: {datetime.now().strftime('%H:%M:%S')}",
        "-" * 62,
        f"  CUSTOMER DETAILS:",
        f"    Name    : {order.get('customer_name')}",
        f"    Contact : {order.get('customer_phone')}",
        f"    Cust ID : {order.get('customer_id')}",
        "-" * 62,
        f"  ORDER SPECIFICATIONS:",
        f"    Cake Type     : {order.get('cake_type')}",
        f"    Flavour       : {order.get('flavour')}",
        f"    Weight & Qty  : {weight} kg x {qty} unit(s)",
        f"    Cake Message  : \"{order.get('cake_message') or 'N/A'}\"",
        f"    Special Notes : {order.get('special_notes') or 'None'}",
        "-" * 62,
        f"  BILLING SUMMARY:",
        f"    Base Price ({weight}kg @ {curr}{price}/kg x {qty}) : {curr}{base:>9.2f}",
        f"    Decoration / Extra Charges       : {curr}{extra:>9.2f}",
        f"    ---------------------------------------------",
        f"    TOTAL AMOUNT                     : {curr}{total:>9.2f}",
        f"    Advance Paid                     : {curr}{advance:>9.2f}",
        f"    BALANCE PENDING                  : {curr}{pending:>9.2f}",
        f"    Payment Status                   : {order.get('payment_status')}",
        "-" * 62,
        f"  PICKUP INFORMATION:",
        f"    Scheduled Date: {order.get('pickup_date')}",
        f"    Scheduled Time: {order.get('pickup_time')}",
        f"    Current Status: {order.get('order_status')}",
        "=" * 62,
        "    Thank you for ordering with Sweet Delights Bakery!",
        "     Please bring this receipt when picking up your cake.",
        "*" * 62,
    ]

    receipt_content = "\n".join(lines)
    try:
        with open(export_path, mode="w", encoding="utf-8") as f:
            f.write(receipt_content)
        return True, export_path, receipt_content
    except Exception as e:
        return False, str(e), receipt_content
