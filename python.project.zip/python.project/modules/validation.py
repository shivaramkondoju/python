"""Validation and Sanitization utilities for Bakery Order Register."""

import re
from datetime import datetime, date
from typing import Tuple, Optional, List


def sanitize_string(value: str) -> str:
    """Strip whitespace and normalize spacing."""
    if value is None:
        return ""
    return str(value).strip()


def validate_customer_name(name: str) -> Tuple[bool, str]:
    """
    Validates customer name.
    Rule: Cannot be empty, must be at least 2 characters, contains valid characters.
    """
    clean = sanitize_string(name)
    if not clean:
        return False, "Customer name cannot be empty."
    if len(clean) < 2:
        return False, "Customer name must be at least 2 characters long."
    if not re.match(r"^[A-Za-z\s\.\'-]+$", clean):
        return False, "Customer name can only contain letters, spaces, dots, and hyphens."
    return True, clean


def validate_mobile_number(phone: str) -> Tuple[bool, str]:
    """
    Validates mobile number.
    Rule: Exactly 10 digits for Indian numbers (starting with 6-9).
    Accepts input with optional +91, 0 prefix, spaces, or hyphens.
    """
    clean = sanitize_string(phone)
    # Remove all non-digit characters
    digits = re.sub(r"\D", "", clean)
    
    # Strip leading country code (+91 or 91 or 0)
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
        
    if len(digits) != 10:
        return False, "Mobile number must be exactly 10 digits."
    
    if digits[0] not in "6789":
        return False, "Indian mobile numbers must start with 6, 7, 8, or 9."
        
    return True, digits


def validate_weight(weight: any) -> Tuple[bool, float, str]:
    """
    Validates cake weight in kilograms.
    Rule: Must be a positive number greater than 0.
    """
    try:
        val = float(weight)
        if val <= 0:
            return False, 0.0, "Cake weight must be greater than zero kg."
        if val > 100:
            return False, 0.0, "Cake weight seems unrealistically high (>100 kg)."
        return True, round(val, 2), ""
    except (ValueError, TypeError):
        return False, 0.0, "Invalid weight! Please enter a valid decimal number."


def validate_quantity(qty: any) -> Tuple[bool, int, str]:
    """
    Validates order quantity.
    Rule: Must be a positive integer (>= 1).
    """
    try:
        val = int(qty)
        if val < 1:
            return False, 0, "Quantity must be a positive integer (at least 1)."
        if val > 1000:
            return False, 0, "Quantity seems unrealistically high (>1000 units)."
        return True, val, ""
    except (ValueError, TypeError):
        return False, 0, "Invalid quantity! Please enter an integer."


def validate_price(price: any, allow_zero: bool = True) -> Tuple[bool, float, str]:
    """
    Validates price per kg or extra charge.
    Rule: Cannot be negative.
    """
    try:
        val = float(price)
        if allow_zero:
            if val < 0:
                return False, 0.0, "Amount cannot be negative."
        else:
            if val <= 0:
                return False, 0.0, "Price must be greater than zero."
        return True, round(val, 2), ""
    except (ValueError, TypeError):
        return False, 0.0, "Invalid price! Please enter a valid numeric value."


def validate_advance_payment(advance: any, total_amount: float) -> Tuple[bool, float, str]:
    """
    Validates advance payment against total amount.
    Rule: Cannot be negative, cannot exceed total amount.
    """
    try:
        val = float(advance)
        if val < 0:
            return False, 0.0, "Advance payment cannot be negative."
        if round(val, 2) > round(total_amount, 2):
            return False, 0.0, f"Advance payment (₹{val:.2f}) cannot exceed total amount (₹{total_amount:.2f})."
        return True, round(val, 2), ""
    except (ValueError, TypeError):
        return False, 0.0, "Invalid advance payment! Please enter a valid number."


def validate_date(date_str: str, allow_past: bool = False, min_date: Optional[date] = None) -> Tuple[bool, str, str]:
    """
    Validates date string in YYYY-MM-DD or DD-MM-YYYY format.
    Returns normalized YYYY-MM-DD string.
    """
    clean = sanitize_string(date_str)
    if not clean:
        return False, "", "Date cannot be empty."

    parsed_date = None
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
        try:
            parsed_date = datetime.strptime(clean, fmt).date()
            break
        except ValueError:
            continue

    if not parsed_date:
        return False, "", "Invalid date format! Please use YYYY-MM-DD or DD-MM-YYYY."

    today = date.today()
    if not allow_past:
        check_baseline = min_date if min_date else today
        if parsed_date < check_baseline:
            return False, "", f"Date ({parsed_date.isoformat()}) cannot be before {check_baseline.isoformat()}."

    return True, parsed_date.strftime("%Y-%m-%d"), ""


def validate_order_id(order_id: str, existing_ids: Optional[List[str]] = None) -> Tuple[bool, str]:
    """
    Validates order ID uniqueness and format (e.g. B001, B002).
    """
    clean = sanitize_string(order_id).upper()
    if not clean:
        return False, "Order ID cannot be empty."
    if not re.match(r"^[A-Z0-9_\-]+$", clean):
        return False, "Order ID can only contain alphanumeric characters, hyphens, and underscores."
    if existing_ids and clean in existing_ids:
        return False, f"Order ID '{clean}' already exists. Order ID must be unique."
    return True, clean
