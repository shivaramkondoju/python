"""Business Analytics and Visualization Module for Bakery Order Register."""

from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

import config
import storage.database as db


def get_business_summary(orders: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """
    Computes key performance indicators (KPIs) and summaries across orders.
    """
    if orders is None:
        orders = db.load_orders()

    total_orders = len(orders)
    if total_orders == 0:
        return {
            "total_orders": 0,
            "total_revenue": 0.0,
            "total_collected": 0.0,
            "total_pending": 0.0,
            "completed_orders": 0,
            "active_orders": 0,
            "cancelled_orders": 0,
            "average_order_value": 0.0,
            "popular_flavours": [],
            "popular_types": [],
            "status_distribution": {},
            "payment_distribution": {},
            "monthly_sales": {}
        }

    total_revenue = 0.0
    total_collected = 0.0
    total_pending = 0.0
    completed_orders = 0
    cancelled_orders = 0
    active_orders = 0

    status_dist: Dict[str, int] = {}
    payment_dist: Dict[str, int] = {}
    flavour_counter: Counter = Counter()
    type_counter: Counter = Counter()
    monthly_sales: Dict[str, float] = {}

    for o in orders:
        st = o.get("order_status", "Pending")
        pay_st = o.get("payment_status", "Pending")
        tot = float(o.get("total_amount", 0.0))
        adv = float(o.get("advance_paid", 0.0))
        pnd = float(o.get("pending_amount", 0.0))
        flav = o.get("flavour", "Unknown")
        c_type = o.get("cake_type", "Standard")
        o_date = o.get("order_date", "")

        status_dist[st] = status_dist.get(st, 0) + 1
        payment_dist[pay_st] = payment_dist.get(pay_st, 0) + 1

        if st == "Cancelled":
            cancelled_orders += 1
            continue

        if st == "Completed":
            completed_orders += 1
        else:
            active_orders += 1

        total_revenue += tot
        total_collected += adv
        total_pending += pnd

        flavour_counter[flav] += 1
        type_counter[c_type] += 1

        if len(o_date) >= 7:
            month_key = o_date[:7]  # YYYY-MM
            monthly_sales[month_key] = monthly_sales.get(month_key, 0.0) + tot

    valid_orders_count = total_orders - cancelled_orders
    avg_order_value = (total_revenue / valid_orders_count) if valid_orders_count > 0 else 0.0

    return {
        "total_orders": total_orders,
        "valid_orders": valid_orders_count,
        "total_revenue": round(total_revenue, 2),
        "total_collected": round(total_collected, 2),
        "total_pending": round(total_pending, 2),
        "completed_orders": completed_orders,
        "active_orders": active_orders,
        "cancelled_orders": cancelled_orders,
        "average_order_value": round(avg_order_value, 2),
        "popular_flavours": flavour_counter.most_common(5),
        "popular_types": type_counter.most_common(5),
        "status_distribution": status_dist,
        "payment_distribution": payment_dist,
        "monthly_sales": dict(sorted(monthly_sales.items()))
    }


def generate_sales_charts(
    orders: Optional[List[Dict[str, Any]]] = None,
    output_image_path: Optional[str] = None
) -> Optional[str]:
    """
    Generates analytics graphs using Matplotlib and saves to PNG file.
    Creates 3 insightful subplots:
    1. Top 5 Most Popular Cake Flavours (Horizontal Bar Chart)
    2. Order Status Breakdown (Pie Chart)
    3. Monthly Revenue Trend (Bar/Line Chart)
    """
    try:
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive backend safe for file generation
        import matplotlib.pyplot as plt

        summary = get_business_summary(orders)
        if summary["total_orders"] == 0:
            return None

        if not output_image_path:
            output_image_path = str(config.REPORTS_DIR / "business_analytics_dashboard.png")

        fig = plt.figure(figsize=(13, 8), dpi=120)
        fig.suptitle(f"{config.BAKERY_INFO['name']} - Business Analytics Dashboard", fontsize=16, fontweight='bold', color="#3E2723")

        # Color palette
        warm_colors = ['#8D6E63', '#D4A373', '#E6B89C', '#C25953', '#A8DADC', '#457B9D']

        # Subplot 1: Top Flavours
        ax1 = fig.add_subplot(2, 2, 1)
        flavours = [item[0] for item in summary["popular_flavours"]]
        counts = [item[1] for item in summary["popular_flavours"]]
        if flavours:
            ax1.barh(flavours[::-1], counts[::-1], color='#D4A373', edgecolor='#3E2723')
            ax1.set_title("Top 5 Cake Flavours", fontsize=12, fontweight='bold')
            ax1.set_xlabel("Orders Count")
            for i, v in enumerate(counts[::-1]):
                ax1.text(v + 0.1, i, str(v), color='#3E2723', va='center', fontweight='bold')
        else:
            ax1.text(0.5, 0.5, "No Flavour Data", ha='center', va='center')

        # Subplot 2: Order Statuses Pie Chart
        ax2 = fig.add_subplot(2, 2, 2)
        status_dist = summary["status_distribution"]
        if status_dist:
            labels = list(status_dist.keys())
            sizes = list(status_dist.values())
            ax2.pie(
                sizes,
                labels=labels,
                autopct='%1.1f%%',
                startangle=140,
                colors=warm_colors[:len(labels)],
                wedgeprops={'edgecolor': 'white', 'linewidth': 1.5}
            )
            ax2.set_title("Order Status Distribution", fontsize=12, fontweight='bold')
        else:
            ax2.text(0.5, 0.5, "No Status Data", ha='center', va='center')

        # Subplot 3: Monthly Revenue
        ax3 = fig.add_subplot(2, 1, 2)
        monthly = summary["monthly_sales"]
        if monthly:
            months = list(monthly.keys())
            revenues = list(monthly.values())
            bars = ax3.bar(months, revenues, color='#C25953', width=0.4, edgecolor='#3E2723')
            ax3.set_title("Monthly Revenue Overview (₹)", fontsize=12, fontweight='bold')
            ax3.set_ylabel("Revenue (₹)")
            ax3.grid(axis='y', linestyle='--', alpha=0.5)
            for bar in bars:
                height = bar.get_height()
                ax3.text(
                    bar.get_x() + bar.get_width() / 2.0,
                    height + (max(revenues) * 0.02),
                    f"₹{int(height):,}",
                    ha='center',
                    va='bottom',
                    fontsize=9,
                    fontweight='bold'
                )
        else:
            ax3.text(0.5, 0.5, "No Monthly Data", ha='center', va='center')

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig(output_image_path, format="png")
        plt.close(fig)

        return output_image_path
    except Exception as e:
        print(f"Warning: Chart generation encountered error ({e})")
        return None
