"""Customer Management Module for Bakery Order Register."""

from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

import storage.database as db
from modules.validation import (
    validate_customer_name,
    validate_mobile_number,
    sanitize_string
)


def get_all_customers() -> List[Dict[str, Any]]:
    """Loads and returns all customers."""
    return db.load_customers()


def find_customer_by_phone(phone: str, customers: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Finds an existing customer by exact 10-digit mobile number."""
    if customers is None:
        customers = db.load_customers()
    is_valid, clean_phone = validate_mobile_number(phone)
    if not is_valid:
        return None
    for cust in customers:
        if cust.get("phone") == clean_phone:
            return cust
    return None


def find_customer_by_id(customer_id: str, customers: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Finds a customer by Customer ID (e.g. C001)."""
    if customers is None:
        customers = db.load_customers()
    cid = sanitize_string(customer_id).upper()
    for cust in customers:
        if cust.get("customer_id", "").upper() == cid:
            return cust
    return None


def register_customer(
    name: str,
    phone: str,
    address: str = "",
    email: str = ""
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Registers a new customer after validation.
    Returns (success, customer_dict, message).
    """
    valid_name, clean_name = validate_customer_name(name)
    if not valid_name:
        return False, None, clean_name

    valid_phone, clean_phone = validate_mobile_number(phone)
    if not valid_phone:
        return False, None, clean_phone

    customers = db.load_customers()

    # Check for duplicate phone
    existing = find_customer_by_phone(clean_phone, customers)
    if existing:
        return False, existing, f"Customer with phone {clean_phone} already exists (ID: {existing['customer_id']})."

    new_id = db.get_next_customer_id(customers)
    new_cust = {
        "customer_id": new_id,
        "name": clean_name,
        "phone": clean_phone,
        "address": sanitize_string(address),
        "email": sanitize_string(email),
        "total_orders": 0,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    customers.append(new_cust)
    db.save_customers(customers)
    return True, new_cust, f"Customer {clean_name} ({new_id}) registered successfully."


def get_or_create_customer(
    name: str,
    phone: str,
    address: str = "",
    email: str = ""
) -> Tuple[bool, Dict[str, Any], str]:
    """
    Finds existing customer by phone number, or creates a new customer record.
    Returns (is_new, customer_dict, message).
    """
    customers = db.load_customers()
    valid_phone, clean_phone = validate_mobile_number(phone)
    if not valid_phone:
        return False, {}, clean_phone

    existing = find_customer_by_phone(clean_phone, customers)
    if existing:
        # Optionally update address or name if provided
        updated = False
        valid_name, clean_name = validate_customer_name(name)
        if valid_name and existing.get("name") != clean_name:
            existing["name"] = clean_name
            updated = True
        if address and not existing.get("address"):
            existing["address"] = sanitize_string(address)
            updated = True
        if updated:
            db.save_customers(customers)
        return False, existing, f"Found existing customer: {existing['name']} ({existing['customer_id']})"

    success, new_cust, msg = register_customer(name, phone, address, email)
    return True, new_cust or {}, msg


def increment_customer_orders(customer_id: str) -> None:
    """Increments the total order counter for a customer."""
    customers = db.load_customers()
    for cust in customers:
        if cust.get("customer_id") == customer_id:
            cust["total_orders"] = int(cust.get("total_orders", 0)) + 1
            db.save_customers(customers)
            break


def search_customers(query: str) -> List[Dict[str, Any]]:
    """Searches customers by name, phone, or customer ID."""
    q = sanitize_string(query).lower()
    if not q:
        return get_all_customers()
    customers = get_all_customers()
    results = []
    for c in customers:
        if (
            q in c.get("name", "").lower()
            or q in c.get("phone", "").lower()
            or q in c.get("customer_id", "").lower()
            or q in c.get("address", "").lower()
        ):
            results.append(c)
    return results
