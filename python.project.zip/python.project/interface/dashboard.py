"""Modern Tkinter GUI Dashboard for Bakery Order Register."""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, date
from pathlib import Path
from typing import Optional, List, Dict, Any

import config
import storage.database as db
import modules.order as order_mod
import modules.customer as cust_mod
import modules.payment as pay_mod
import modules.pickup as pick_mod
import modules.search as search_mod
import modules.analytics as ana_mod
import modules.reports as rep_mod
from modules.calculation import calculate_total_amount, calculate_pending_amount, determine_payment_status


class BakeryDashboardGUI(tk.Tk):
    """Main Application Window for Bakery Order Register."""

    def __init__(self):
        super().__init__()
        self.title(f"{config.BAKERY_INFO['name']} - Order Register")
        self.geometry("1100x720")
        self.minsize(980, 640)

        # Theme Colors
        self.primary_color = "#3E2723"    # Deep Chocolate
        self.accent_color = "#C25953"     # Berry Red
        self.warm_bg = "#FAF7F2"          # Warm Cream
        self.card_bg = "#FFFFFF"          # Pure White
        self.text_dark = "#261C14"        # Dark Roast

        self.configure(bg=self.warm_bg)
        self._setup_styles()
        self._build_header()
        self._build_tabs()

        # Load initial data
        self.refresh_all_views()

    def _setup_styles(self):
        """Configure TTK widget styles."""
        style = ttk.Style(self)
        style.theme_use("clam")

        style.configure("TNotebook", background=self.warm_bg)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=[16, 6])
        style.map("TNotebook.Tab", background=[("selected", self.primary_color)], foreground=[("selected", "white")])

        style.configure("Treeview", font=("Segoe UI", 9), rowheight=26, background="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background="#EFEBE9", foreground=self.primary_color)
        style.map("Treeview", background=[("selected", "#D7CCC8")], foreground=[("selected", "#000000")])

        style.configure("Action.TButton", font=("Segoe UI", 9, "bold"), padding=6)
        style.configure("Accent.TButton", font=("Segoe UI", 9, "bold"), foreground="white", background=self.accent_color)

    def _build_header(self):
        """Header Banner with bakery branding."""
        header_frame = tk.Frame(self, bg=self.primary_color, height=75)
        header_frame.pack(side="top", fill="x")

        title_lbl = tk.Label(
            header_frame,
            text=f"🍰  {config.BAKERY_INFO['name'].upper()}",
            font=("Segoe UI", 16, "bold"),
            fg="#FFF8E1",
            bg=self.primary_color
        )
        title_lbl.pack(side="left", padx=20, pady=10)

        sub_lbl = tk.Label(
            header_frame,
            text=f"📞 {config.BAKERY_INFO['phone']}  |  {config.BAKERY_INFO['fssai_lic']}",
            font=("Segoe UI", 9),
            fg="#D7CCC8",
            bg=self.primary_color
        )
        sub_lbl.pack(side="right", padx=20, pady=10)

    def _build_tabs(self):
        """Builds tabbed navigation."""
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=10)

        # Tab 1: Orders Register
        self.tab_orders = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_orders, text="📋 Orders Register")
        self._init_orders_tab()

        # Tab 2: New Order Form
        self.tab_new_order = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_new_order, text="➕ Add New Order")
        self._init_new_order_tab()

        # Tab 3: Customer Directory
        self.tab_customers = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_customers, text="👥 Customers")
        self._init_customers_tab()

        # Tab 4: Pickup & Payment Alerts
        self.tab_alerts = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_alerts, text="🔔 Pickup & Alerts")
        self._init_alerts_tab()

        # Tab 5: Analytics & Charts
        self.tab_analytics = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_analytics, text="📊 Business Analytics")
        self._init_analytics_tab()

        # Tab 6: Reports & Tools
        self.tab_reports = tk.Frame(self.notebook, bg=self.warm_bg)
        self.notebook.add(self.tab_reports, text="⚙️ Reports & Tools")
        self._init_reports_tab()

    # -------------------------------------------------------------------------
    # TAB 1: ORDERS REGISTER
    # -------------------------------------------------------------------------
    def _init_orders_tab(self):
        top_bar = tk.Frame(self.tab_orders, bg=self.warm_bg)
        top_bar.pack(fill="x", padx=10, pady=8)

        tk.Label(top_bar, text="Search:", font=("Segoe UI", 9, "bold"), bg=self.warm_bg).pack(side="left", padx=(0, 5))
        self.search_entry = ttk.Entry(top_bar, width=22)
        self.search_entry.pack(side="left", padx=5)
        self.search_entry.bind("<KeyRelease>", lambda e: self.filter_orders_table())

        tk.Label(top_bar, text="Status:", font=("Segoe UI", 9, "bold"), bg=self.warm_bg).pack(side="left", padx=(15, 5))
        self.status_filter = ttk.Combobox(top_bar, values=["All"] + config.ORDER_STATUSES, state="readonly", width=14)
        self.status_filter.current(0)
        self.status_filter.pack(side="left", padx=5)
        self.status_filter.bind("<<ComboboxSelected>>", lambda e: self.filter_orders_table())

        tk.Label(top_bar, text="Payment:", font=("Segoe UI", 9, "bold"), bg=self.warm_bg).pack(side="left", padx=(15, 5))
        self.pay_filter = ttk.Combobox(top_bar, values=["All"] + config.PAYMENT_STATUSES, state="readonly", width=14)
        self.pay_filter.current(0)
        self.pay_filter.pack(side="left", padx=5)
        self.pay_filter.bind("<<ComboboxSelected>>", lambda e: self.filter_orders_table())

        ttk.Button(top_bar, text="🔄 Refresh", command=self.refresh_all_views).pack(side="right", padx=5)

        # Table frame
        table_frame = tk.Frame(self.tab_orders)
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)

        cols = ("order_id", "customer_name", "phone", "flavour", "weight_kg", "total", "advance", "pending", "payment_status", "pickup_date", "pickup_time", "order_status")
        self.orders_tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")

        self.orders_tree.heading("order_id", text="ID")
        self.orders_tree.heading("customer_name", text="Customer Name")
        self.orders_tree.heading("phone", text="Phone")
        self.orders_tree.heading("flavour", text="Flavour")
        self.orders_tree.heading("weight_kg", text="Wt (kg)")
        self.orders_tree.heading("total", text="Total (₹)")
        self.orders_tree.heading("advance", text="Paid (₹)")
        self.orders_tree.heading("pending", text="Pending (₹)")
        self.orders_tree.heading("payment_status", text="Payment")
        self.orders_tree.heading("pickup_date", text="Pickup Date")
        self.orders_tree.heading("pickup_time", text="Time")
        self.orders_tree.heading("order_status", text="Order Status")

        self.orders_tree.column("order_id", width=65, anchor="center")
        self.orders_tree.column("customer_name", width=130)
        self.orders_tree.column("phone", width=100, anchor="center")
        self.orders_tree.column("flavour", width=130)
        self.orders_tree.column("weight_kg", width=65, anchor="center")
        self.orders_tree.column("total", width=80, anchor="e")
        self.orders_tree.column("advance", width=75, anchor="e")
        self.orders_tree.column("pending", width=85, anchor="e")
        self.orders_tree.column("payment_status", width=95, anchor="center")
        self.orders_tree.column("pickup_date", width=95, anchor="center")
        self.orders_tree.column("pickup_time", width=70, anchor="center")
        self.orders_tree.column("order_status", width=110, anchor="center")

        tree_scroll_y = ttk.Scrollbar(table_frame, orient="vertical", command=self.orders_tree.yview)
        tree_scroll_x = ttk.Scrollbar(table_frame, orient="horizontal", command=self.orders_tree.xview)
        self.orders_tree.configure(yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)

        self.orders_tree.pack(side="left", fill="both", expand=True)
        tree_scroll_y.pack(side="right", fill="y")
        tree_scroll_x.pack(side="bottom", fill="x")

        # Bottom Actions Bar
        bot_bar = tk.Frame(self.tab_orders, bg=self.warm_bg)
        bot_bar.pack(fill="x", padx=10, pady=8)

        ttk.Button(bot_bar, text="✅ Mark Completed", command=self._action_mark_completed).pack(side="left", padx=4)
        ttk.Button(bot_bar, text="🎂 Mark Ready for Pickup", command=self._action_mark_ready).pack(side="left", padx=4)
        ttk.Button(bot_bar, text="💵 Record Payment", command=self._action_record_payment).pack(side="left", padx=4)
        ttk.Button(bot_bar, text="📄 View / Print Invoice", command=self._action_print_invoice).pack(side="left", padx=4)
        ttk.Button(bot_bar, text="🗑️ Delete Order", command=self._action_delete_order).pack(side="right", padx=4)

    def filter_orders_table(self):
        """Filters table according to search text and dropdowns."""
        q = self.search_entry.get().strip()
        st = self.status_filter.get()
        pst = self.pay_filter.get()

        orders = search_mod.search_orders(
            query=q if q else None,
            order_status=st if st != "All" else None,
            payment_status=pst if pst != "All" else None
        )
        self._populate_orders_tree(orders)

    def _populate_orders_tree(self, orders: List[Dict[str, Any]]):
        for item in self.orders_tree.get_children():
            self.orders_tree.delete(item)

        for o in orders:
            self.orders_tree.insert("", "end", values=(
                o.get("order_id"),
                o.get("customer_name"),
                o.get("customer_phone"),
                o.get("flavour"),
                f"{float(o.get('weight_kg', 1.0)):.1f}",
                f"{float(o.get('total_amount', 0.0)):.2f}",
                f"{float(o.get('advance_paid', 0.0)):.2f}",
                f"{float(o.get('pending_amount', 0.0)):.2f}",
                o.get("payment_status"),
                o.get("pickup_date"),
                o.get("pickup_time"),
                o.get("order_status")
            ))

    def _get_selected_order_id(self) -> Optional[str]:
        selected = self.orders_tree.selection()
        if not selected:
            messagebox.showinfo("Select Order", "Please click on an order in the table first.")
            return None
        values = self.orders_tree.item(selected[0], "values")
        return str(values[0])

    def _action_mark_completed(self):
        oid = self._get_selected_order_id()
        if oid:
            pick_mod.update_order_status(oid, "Completed")
            self.refresh_all_views()
            messagebox.showinfo("Status Updated", f"Order {oid} marked as Completed.")

    def _action_mark_ready(self):
        oid = self._get_selected_order_id()
        if oid:
            pick_mod.update_order_status(oid, "Ready for Pickup")
            self.refresh_all_views()
            messagebox.showinfo("Status Updated", f"Order {oid} marked Ready for Pickup.")

    def _action_delete_order(self):
        oid = self._get_selected_order_id()
        if oid:
            confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete order {oid}?")
            if confirm:
                order_mod.delete_order(oid)
                self.refresh_all_views()
                messagebox.showinfo("Deleted", f"Order {oid} has been removed.")

    def _action_record_payment(self):
        oid = self._get_selected_order_id()
        if not oid:
            return
        order = order_mod.get_order_by_id(oid)
        if not order:
            return

        pending = float(order.get("pending_amount", 0.0))
        if pending <= 0:
            messagebox.showinfo("Fully Paid", f"Order {oid} is already fully paid!")
            return

        # Simple input dialog
        pay_dialog = tk.Toplevel(self)
        pay_dialog.title(f"Record Payment for {oid}")
        pay_dialog.geometry("360x220")
        pay_dialog.configure(bg=self.warm_bg)
        pay_dialog.grab_set()

        tk.Label(pay_dialog, text=f"Order ID: {oid}", font=("Segoe UI", 10, "bold"), bg=self.warm_bg).pack(pady=8)
        tk.Label(pay_dialog, text=f"Customer: {order.get('customer_name')}", bg=self.warm_bg).pack()
        tk.Label(pay_dialog, text=f"Pending Balance: ₹{pending:.2f}", font=("Segoe UI", 10, "bold"), fg=self.accent_color, bg=self.warm_bg).pack(pady=4)

        entry_frame = tk.Frame(pay_dialog, bg=self.warm_bg)
        entry_frame.pack(pady=10)
        tk.Label(entry_frame, text="Amount Received (₹):", bg=self.warm_bg).pack(side="left")
        amt_entry = ttk.Entry(entry_frame, width=12)
        amt_entry.insert(0, f"{pending:.2f}")
        amt_entry.pack(side="left", padx=5)

        def submit():
            try:
                amt = float(amt_entry.get().strip())
                success, _, msg = pay_mod.record_additional_payment(oid, amt)
                if success:
                    messagebox.showinfo("Payment Recorded", msg)
                    pay_dialog.destroy()
                    self.refresh_all_views()
                else:
                    messagebox.showerror("Error", msg)
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid numeric amount.")

        ttk.Button(pay_dialog, text="Confirm Payment", command=submit).pack(pady=10)

    def _action_print_invoice(self):
        oid = self._get_selected_order_id()
        if not oid:
            return
        order = order_mod.get_order_by_id(oid)
        if not order:
            return

        _, inv_path, text = rep_mod.generate_printable_invoice(order)

        # Show preview dialog
        inv_win = tk.Toplevel(self)
        inv_win.title(f"Receipt - {oid}")
        inv_win.geometry("640x550")

        text_area = tk.Text(inv_win, wrap="none", font=("Consolas", 10))
        text_area.insert("1.0", text)
        text_area.configure(state="disabled")
        text_area.pack(fill="both", expand=True, padx=10, pady=10)

        btn_bar = tk.Frame(inv_win)
        btn_bar.pack(fill="x", pady=5)
        tk.Label(btn_bar, text=f"Saved at: {inv_path}", fg="#555", font=("Segoe UI", 8)).pack(side="left", padx=10)
        ttk.Button(btn_bar, text="Close", command=inv_win.destroy).pack(side="right", padx=10)

    # -------------------------------------------------------------------------
    # TAB 2: ADD NEW ORDER FORM
    # -------------------------------------------------------------------------
    def _init_new_order_tab(self):
        container = tk.Frame(self.tab_new_order, bg=self.warm_bg)
        container.pack(fill="both", expand=True, padx=25, pady=15)

        # Left Column: Customer & Cake Basics
        left_frame = tk.LabelFrame(container, text=" Customer & Cake Specifications ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=15, pady=15)
        left_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        tk.Label(left_frame, text="Customer Name *:", bg=self.card_bg).grid(row=0, column=0, sticky="w", pady=6)
        self.form_name = ttk.Entry(left_frame, width=28)
        self.form_name.grid(row=0, column=1, sticky="w", pady=6)

        tk.Label(left_frame, text="Mobile Number (10 digits) *:", bg=self.card_bg).grid(row=1, column=0, sticky="w", pady=6)
        self.form_phone = ttk.Entry(left_frame, width=28)
        self.form_phone.grid(row=1, column=1, sticky="w", pady=6)

        tk.Label(left_frame, text="Delivery Address / Area:", bg=self.card_bg).grid(row=2, column=0, sticky="w", pady=6)
        self.form_address = ttk.Entry(left_frame, width=28)
        self.form_address.grid(row=2, column=1, sticky="w", pady=6)

        tk.Label(left_frame, text="Cake Type *:", bg=self.card_bg).grid(row=3, column=0, sticky="w", pady=6)
        self.form_cake_type = ttk.Combobox(left_frame, values=config.CAKE_TYPES, state="readonly", width=26)
        self.form_cake_type.current(0)
        self.form_cake_type.grid(row=3, column=1, sticky="w", pady=6)

        tk.Label(left_frame, text="Cake Flavour *:", bg=self.card_bg).grid(row=4, column=0, sticky="w", pady=6)
        flavours = list(config.FLAVOUR_BASE_PRICES.keys())
        self.form_flavour = ttk.Combobox(left_frame, values=flavours, state="readonly", width=26)
        self.form_flavour.current(0)
        self.form_flavour.grid(row=4, column=1, sticky="w", pady=6)
        self.form_flavour.bind("<<ComboboxSelected>>", self._on_flavour_change)

        tk.Label(left_frame, text="Weight (kg) *:", bg=self.card_bg).grid(row=5, column=0, sticky="w", pady=6)
        self.form_weight = ttk.Spinbox(left_frame, from_=0.5, to=50.0, increment=0.5, width=12)
        self.form_weight.set(1.0)
        self.form_weight.grid(row=5, column=1, sticky="w", pady=6)
        self.form_weight.bind("<KeyRelease>", lambda e: self._update_pricing_preview())
        self.form_weight.bind("<<Increment>>", lambda e: self._update_pricing_preview())
        self.form_weight.bind("<<Decrement>>", lambda e: self._update_pricing_preview())

        tk.Label(left_frame, text="Quantity *:", bg=self.card_bg).grid(row=6, column=0, sticky="w", pady=6)
        self.form_qty = ttk.Spinbox(left_frame, from_=1, to=100, increment=1, width=12)
        self.form_qty.set(1)
        self.form_qty.grid(row=6, column=1, sticky="w", pady=6)
        self.form_qty.bind("<KeyRelease>", lambda e: self._update_pricing_preview())
        self.form_qty.bind("<<Increment>>", lambda e: self._update_pricing_preview())
        self.form_qty.bind("<<Decrement>>", lambda e: self._update_pricing_preview())

        tk.Label(left_frame, text="Message on Cake:", bg=self.card_bg).grid(row=7, column=0, sticky="w", pady=6)
        self.form_message = ttk.Entry(left_frame, width=28)
        self.form_message.grid(row=7, column=1, sticky="w", pady=6)

        # Right Column: Pricing & Scheduling
        right_frame = tk.LabelFrame(container, text=" Pricing & Pickup Scheduling ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=15, pady=15)
        right_frame.pack(side="right", fill="both", expand=True)

        tk.Label(right_frame, text="Price per kg (₹):", bg=self.card_bg).grid(row=0, column=0, sticky="w", pady=6)
        self.form_price = ttk.Entry(right_frame, width=15)
        self.form_price.insert(0, str(config.FLAVOUR_BASE_PRICES["Chocolate Truffle"]))
        self.form_price.grid(row=0, column=1, sticky="w", pady=6)
        self.form_price.bind("<KeyRelease>", lambda e: self._update_pricing_preview())

        tk.Label(right_frame, text="Extra / Decor Charges (₹):", bg=self.card_bg).grid(row=1, column=0, sticky="w", pady=6)
        self.form_extra = ttk.Entry(right_frame, width=15)
        self.form_extra.insert(0, "0.0")
        self.form_extra.grid(row=1, column=1, sticky="w", pady=6)
        self.form_extra.bind("<KeyRelease>", lambda e: self._update_pricing_preview())

        tk.Label(right_frame, text="Advance Payment (₹):", bg=self.card_bg).grid(row=2, column=0, sticky="w", pady=6)
        self.form_advance = ttk.Entry(right_frame, width=15)
        self.form_advance.insert(0, "0.0")
        self.form_advance.grid(row=2, column=1, sticky="w", pady=6)
        self.form_advance.bind("<KeyRelease>", lambda e: self._update_pricing_preview())

        tk.Label(right_frame, text="Pickup Date (YYYY-MM-DD) *:", bg=self.card_bg).grid(row=3, column=0, sticky="w", pady=6)
        self.form_pickup_date = ttk.Entry(right_frame, width=15)
        self.form_pickup_date.insert(0, date.today().strftime("%Y-%m-%d"))
        self.form_pickup_date.grid(row=3, column=1, sticky="w", pady=6)

        tk.Label(right_frame, text="Pickup Time (e.g. 18:00):", bg=self.card_bg).grid(row=4, column=0, sticky="w", pady=6)
        self.form_pickup_time = ttk.Entry(right_frame, width=15)
        self.form_pickup_time.insert(0, "18:00")
        self.form_pickup_time.grid(row=4, column=1, sticky="w", pady=6)

        tk.Label(right_frame, text="Special Notes:", bg=self.card_bg).grid(row=5, column=0, sticky="w", pady=6)
        self.form_notes = ttk.Entry(right_frame, width=28)
        self.form_notes.grid(row=5, column=1, sticky="w", pady=6)

        # Calculation summary card
        calc_box = tk.Frame(right_frame, bg="#EFEBE9", padx=10, pady=10, relief="groove", borderwidth=1)
        calc_box.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(15, 10))

        self.lbl_calc_total = tk.Label(calc_box, text="Total Amount: ₹0.00", font=("Segoe UI", 11, "bold"), fg=self.primary_color, bg="#EFEBE9")
        self.lbl_calc_total.pack(anchor="w")

        self.lbl_calc_pending = tk.Label(calc_box, text="Pending Balance: ₹0.00", font=("Segoe UI", 11, "bold"), fg=self.accent_color, bg="#EFEBE9")
        self.lbl_calc_pending.pack(anchor="w")

        # Buttons
        btn_frame = tk.Frame(right_frame, bg=self.card_bg)
        btn_frame.grid(row=7, column=0, columnspan=2, pady=10)

        ttk.Button(btn_frame, text="💾 Save Order", command=self._submit_new_order).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🔄 Reset Form", command=self._reset_new_order_form).pack(side="left", padx=5)

        self._update_pricing_preview()

    def _on_flavour_change(self, event=None):
        flav = self.form_flavour.get()
        suggested = config.FLAVOUR_BASE_PRICES.get(flav, 600.0)
        self.form_price.delete(0, tk.END)
        self.form_price.insert(0, f"{suggested:.2f}")
        self._update_pricing_preview()

    def _update_pricing_preview(self):
        try:
            wt = float(self.form_weight.get() or 1.0)
            qty = int(self.form_qty.get() or 1)
            pr = float(self.form_price.get() or 0.0)
            ex = float(self.form_extra.get() or 0.0)
            adv = float(self.form_advance.get() or 0.0)

            total = calculate_total_amount(pr, wt, qty, ex)
            pending = calculate_pending_amount(total, adv)

            self.lbl_calc_total.config(text=f"Total Amount: ₹{total:,.2f}")
            self.lbl_calc_pending.config(text=f"Pending Balance: ₹{pending:,.2f}")
        except Exception:
            pass

    def _reset_new_order_form(self):
        self.form_name.delete(0, tk.END)
        self.form_phone.delete(0, tk.END)
        self.form_address.delete(0, tk.END)
        self.form_message.delete(0, tk.END)
        self.form_notes.delete(0, tk.END)
        self.form_weight.set(1.0)
        self.form_qty.set(1)
        self.form_extra.delete(0, tk.END)
        self.form_extra.insert(0, "0.0")
        self.form_advance.delete(0, tk.END)
        self.form_advance.insert(0, "0.0")
        self.form_pickup_date.delete(0, tk.END)
        self.form_pickup_date.insert(0, date.today().strftime("%Y-%m-%d"))
        self._on_flavour_change()

    def _submit_new_order(self):
        name = self.form_name.get().strip()
        phone = self.form_phone.get().strip()
        address = self.form_address.get().strip()
        ctype = self.form_cake_type.get().strip()
        flav = self.form_flavour.get().strip()
        msg = self.form_message.get().strip()
        pdate = self.form_pickup_date.get().strip()
        ptime = self.form_pickup_time.get().strip()
        notes = self.form_notes.get().strip()

        try:
            wt = float(self.form_weight.get())
            qty = int(self.form_qty.get())
            price = float(self.form_price.get())
            extra = float(self.form_extra.get())
            advance = float(self.form_advance.get())
        except ValueError:
            messagebox.showerror("Validation Error", "Please ensure weight, quantity, price, extra charges, and advance are valid numbers.")
            return

        success, new_order, result_msg = order_mod.register_new_order(
            customer_name=name,
            customer_phone=phone,
            cake_type=ctype,
            flavour=flav,
            weight_kg=wt,
            quantity=qty,
            cake_message=msg,
            price_per_kg=price,
            extra_charges=extra,
            advance_paid=advance,
            pickup_date_str=pdate,
            pickup_time_str=ptime,
            order_status="Pending",
            special_notes=notes,
            customer_address=address
        )

        if success and new_order:
            messagebox.showinfo("Order Saved", f"Order {new_order['order_id']} saved successfully!\nTotal: ₹{new_order['total_amount']:.2f}\nPending: ₹{new_order['pending_amount']:.2f}")
            self._reset_new_order_form()
            self.refresh_all_views()
            self.notebook.select(self.tab_orders)
        else:
            messagebox.showerror("Error", result_msg)

    # -------------------------------------------------------------------------
    # TAB 3: CUSTOMERS DIRECTORY
    # -------------------------------------------------------------------------
    def _init_customers_tab(self):
        top_bar = tk.Frame(self.tab_customers, bg=self.warm_bg)
        top_bar.pack(fill="x", padx=10, pady=8)

        tk.Label(top_bar, text="Search Customer:", font=("Segoe UI", 9, "bold"), bg=self.warm_bg).pack(side="left", padx=5)
        self.cust_search_entry = ttk.Entry(top_bar, width=25)
        self.cust_search_entry.pack(side="left", padx=5)
        self.cust_search_entry.bind("<KeyRelease>", lambda e: self.filter_customers_table())

        ttk.Button(top_bar, text="➕ Quick Register Customer", command=self._quick_register_customer).pack(side="right", padx=5)

        table_frame = tk.Frame(self.tab_customers)
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)

        cols = ("customer_id", "name", "phone", "address", "total_orders", "created_at")
        self.cust_tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")

        self.cust_tree.heading("customer_id", text="Customer ID")
        self.cust_tree.heading("name", text="Customer Name")
        self.cust_tree.heading("phone", text="Mobile Number")
        self.cust_tree.heading("address", text="Address / City")
        self.cust_tree.heading("total_orders", text="Total Orders Placed")
        self.cust_tree.heading("created_at", text="Registered On")

        self.cust_tree.column("customer_id", width=100, anchor="center")
        self.cust_tree.column("name", width=180)
        self.cust_tree.column("phone", width=130, anchor="center")
        self.cust_tree.column("address", width=220)
        self.cust_tree.column("total_orders", width=130, anchor="center")
        self.cust_tree.column("created_at", width=140, anchor="center")

        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.cust_tree.yview)
        self.cust_tree.configure(yscrollcommand=scroll.set)
        self.cust_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def filter_customers_table(self):
        q = self.cust_search_entry.get().strip()
        customers = cust_mod.search_customers(q)
        self._populate_customers_tree(customers)

    def _populate_customers_tree(self, customers: List[Dict[str, Any]]):
        for item in self.cust_tree.get_children():
            self.cust_tree.delete(item)
        for c in customers:
            self.cust_tree.insert("", "end", values=(
                c.get("customer_id"),
                c.get("name"),
                c.get("phone"),
                c.get("address"),
                c.get("total_orders", 0),
                str(c.get("created_at", ""))[:19]
            ))

    def _quick_register_customer(self):
        reg_win = tk.Toplevel(self)
        reg_win.title("Register New Customer")
        reg_win.geometry("380x260")
        reg_win.configure(bg=self.warm_bg)

        tk.Label(reg_win, text="Customer Name *:", bg=self.warm_bg).pack(pady=(12, 2))
        name_e = ttk.Entry(reg_win, width=28)
        name_e.pack()

        tk.Label(reg_win, text="Mobile Number (10 digits) *:", bg=self.warm_bg).pack(pady=(8, 2))
        phone_e = ttk.Entry(reg_win, width=28)
        phone_e.pack()

        tk.Label(reg_win, text="Address / City:", bg=self.warm_bg).pack(pady=(8, 2))
        addr_e = ttk.Entry(reg_win, width=28)
        addr_e.pack()

        def do_reg():
            s, c, msg = cust_mod.register_customer(name_e.get().strip(), phone_e.get().strip(), addr_e.get().strip())
            if s:
                messagebox.showinfo("Success", msg)
                reg_win.destroy()
                self.refresh_all_views()
            else:
                messagebox.showerror("Error", msg)

        ttk.Button(reg_win, text="Register Customer", command=do_reg).pack(pady=15)

    # -------------------------------------------------------------------------
    # TAB 4: PICKUP & ALERTS TAB
    # -------------------------------------------------------------------------
    def _init_alerts_tab(self):
        paned = ttk.PanedWindow(self.tab_alerts, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=10, pady=10)

        # Left: Today's and Upcoming Pickups
        left_sub = tk.LabelFrame(paned, text=" 📅 Upcoming & Today's Pickups ", font=("Segoe UI", 10, "bold"), bg=self.warm_bg, padx=8, pady=8)
        paned.add(left_sub, weight=1)

        self.tree_upcoming = ttk.Treeview(left_sub, columns=("id", "customer", "phone", "flavour", "pickup", "status"), show="headings")
        self.tree_upcoming.heading("id", text="ID")
        self.tree_upcoming.heading("customer", text="Customer")
        self.tree_upcoming.heading("phone", text="Phone")
        self.tree_upcoming.heading("flavour", text="Flavour")
        self.tree_upcoming.heading("pickup", text="Pickup")
        self.tree_upcoming.heading("status", text="Status")

        self.tree_upcoming.column("id", width=60, anchor="center")
        self.tree_upcoming.column("customer", width=110)
        self.tree_upcoming.column("phone", width=95, anchor="center")
        self.tree_upcoming.column("flavour", width=110)
        self.tree_upcoming.column("pickup", width=85, anchor="center")
        self.tree_upcoming.column("status", width=90, anchor="center")
        self.tree_upcoming.pack(fill="both", expand=True)

        # Right: Overdue & Payment Alerts
        right_sub = tk.LabelFrame(paned, text=" ⚠️ Overdue Pickups & Low-Payment Alerts ", font=("Segoe UI", 10, "bold"), bg=self.warm_bg, padx=8, pady=8)
        paned.add(right_sub, weight=1)

        self.tree_alerts = ttk.Treeview(right_sub, columns=("id", "customer", "phone", "total", "pending", "pickup", "type"), show="headings")
        self.tree_alerts.heading("id", text="ID")
        self.tree_alerts.heading("customer", text="Customer")
        self.tree_alerts.heading("phone", text="Phone")
        self.tree_alerts.heading("total", text="Total (₹)")
        self.tree_alerts.heading("pending", text="Pending (₹)")
        self.tree_alerts.heading("pickup", text="Pickup")
        self.tree_alerts.heading("type", text="Alert Type")

        self.tree_alerts.column("id", width=60, anchor="center")
        self.tree_alerts.column("customer", width=110)
        self.tree_alerts.column("phone", width=95, anchor="center")
        self.tree_alerts.column("total", width=75, anchor="e")
        self.tree_alerts.column("pending", width=80, anchor="e")
        self.tree_alerts.column("pickup", width=85, anchor="center")
        self.tree_alerts.column("type", width=110, anchor="center")
        self.tree_alerts.pack(fill="both", expand=True)

    def _populate_alerts(self):
        for item in self.tree_upcoming.get_children():
            self.tree_upcoming.delete(item)
        upcoming = pick_mod.get_upcoming_pickups(days=7)
        for o in upcoming:
            self.tree_upcoming.insert("", "end", values=(
                o.get("order_id"),
                o.get("customer_name"),
                o.get("customer_phone"),
                o.get("flavour"),
                o.get("pickup_date"),
                o.get("order_status")
            ))

        for item in self.tree_alerts.get_children():
            self.tree_alerts.delete(item)

        overdue = pick_mod.get_overdue_pickups()
        for o in overdue:
            self.tree_alerts.insert("", "end", values=(
                o.get("order_id"),
                o.get("customer_name"),
                o.get("customer_phone"),
                f"{float(o.get('total_amount', 0.0)):.0f}",
                f"{float(o.get('pending_amount', 0.0)):.0f}",
                o.get("pickup_date"),
                "⚠️ OVERDUE"
            ))

        low_pay = pay_mod.get_low_payment_alerts()
        for o in low_pay:
            if o in overdue:
                continue
            self.tree_alerts.insert("", "end", values=(
                o.get("order_id"),
                o.get("customer_name"),
                o.get("customer_phone"),
                f"{float(o.get('total_amount', 0.0)):.0f}",
                f"{float(o.get('pending_amount', 0.0)):.0f}",
                o.get("pickup_date"),
                "🔔 PENDING PAYMENT"
            ))

    # -------------------------------------------------------------------------
    # TAB 5: BUSINESS ANALYTICS & CHARTS
    # -------------------------------------------------------------------------
    def _init_analytics_tab(self):
        container = tk.Frame(self.tab_analytics, bg=self.warm_bg)
        container.pack(fill="both", expand=True, padx=20, pady=15)

        # KPI Cards Frame
        kpi_frame = tk.Frame(container, bg=self.warm_bg)
        kpi_frame.pack(fill="x", pady=(0, 15))

        self.card_orders = self._create_kpi_card(kpi_frame, "Total Orders", "0", "#3E2723")
        self.card_revenue = self._create_kpi_card(kpi_frame, "Total Revenue", "₹0.00", "#1B5E20")
        self.card_collected = self._create_kpi_card(kpi_frame, "Advance Collected", "₹0.00", "#0277BD")
        self.card_pending = self._create_kpi_card(kpi_frame, "Pending Balance", "₹0.00", "#C25953")

        # Lower section: popular items & chart generator
        bot_frame = tk.Frame(container, bg=self.warm_bg)
        bot_frame.pack(fill="both", expand=True)

        fav_frame = tk.LabelFrame(bot_frame, text=" 🏆 Top 5 Customer Favorite Flavours ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=12, pady=10)
        fav_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.fav_text = tk.Text(fav_frame, font=("Segoe UI", 10), bg=self.card_bg, relief="flat")
        self.fav_text.pack(fill="both", expand=True)

        chart_ctrl = tk.LabelFrame(bot_frame, text=" 📈 Visual Graphs & Charts ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=15, pady=15)
        chart_ctrl.pack(side="right", fill="both", expand=True)

        tk.Label(
            chart_ctrl,
            text="Generate high-resolution Matplotlib graphs for:\n• Top 5 Most Popular Cake Flavours\n• Order Status Breakdown\n• Monthly Revenue Trends",
            justify="left",
            font=("Segoe UI", 10),
            bg=self.card_bg
        ).pack(pady=10)

        ttk.Button(chart_ctrl, text="📊 Generate & View Analytics Charts", command=self._open_chart_window).pack(pady=12)

    def _create_kpi_card(self, parent, title: str, value: str, color: str) -> tk.Label:
        card = tk.Frame(parent, bg=self.card_bg, padx=15, pady=12, relief="groove", borderwidth=1)
        card.pack(side="left", fill="both", expand=True, padx=6)
        tk.Label(card, text=title, font=("Segoe UI", 9, "bold"), fg="#795548", bg=self.card_bg).pack(anchor="w")
        val_lbl = tk.Label(card, text=value, font=("Segoe UI", 14, "bold"), fg=color, bg=self.card_bg)
        val_lbl.pack(anchor="w", pady=(4, 0))
        return val_lbl

    def _populate_analytics(self):
        summary = ana_mod.get_business_summary()
        curr = config.BAKERY_INFO["currency_symbol"]

        self.card_orders.config(text=f"{summary['total_orders']}")
        self.card_revenue.config(text=f"{curr}{summary['total_revenue']:,.2f}")
        self.card_collected.config(text=f"{curr}{summary['total_collected']:,.2f}")
        self.card_pending.config(text=f"{curr}{summary['total_pending']:,.2f}")

        self.fav_text.config(state="normal")
        self.fav_text.delete("1.0", tk.END)
        for idx, (flav, count) in enumerate(summary["popular_flavours"], 1):
            self.fav_text.insert(tk.END, f"{idx}. {flav:<25} : {count} orders placed\n\n")
        self.fav_text.config(state="disabled")

    def _open_chart_window(self):
        chart_path = ana_mod.generate_sales_charts()
        if not chart_path:
            messagebox.showerror("Error", "Could not generate charts. Ensure Matplotlib is installed.")
            return

        win = tk.Toplevel(self)
        win.title("Sales & Business Analytics Graphs")
        win.geometry("900x650")

        try:
            from PIL import Image, ImageTk
            img = Image.open(chart_path)
            img = img.resize((860, 560), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            lbl = tk.Label(win, image=photo)
            lbl.image = photo
            lbl.pack(fill="both", expand=True, padx=10, pady=10)
        except Exception:
            # Fallback if Pillow is not present: show path and prompt to open externally
            tk.Label(win, text=f"Chart generated and saved to:\n{chart_path}", font=("Segoe UI", 11)).pack(pady=30)
            ttk.Button(win, text="Open File", command=lambda: os.startfile(chart_path) if hasattr(os, "startfile") else None).pack(pady=10)

    # -------------------------------------------------------------------------
    # TAB 6: REPORTS & TOOLS
    # -------------------------------------------------------------------------
    def _init_reports_tab(self):
        container = tk.Frame(self.tab_reports, bg=self.warm_bg)
        container.pack(fill="both", expand=True, padx=25, pady=20)

        # Reports Group
        rep_box = tk.LabelFrame(container, text=" 📑 Business Report Exports ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=15, pady=15)
        rep_box.pack(side="left", fill="both", expand=True, padx=(0, 10))

        ttk.Button(rep_box, text="📥 Export All Orders to CSV", command=self._export_all_csv).pack(fill="x", pady=6)
        ttk.Button(rep_box, text="📅 Generate Daily Sales Report (CSV)", command=self._export_daily_report).pack(fill="x", pady=6)
        ttk.Button(rep_box, text="📆 Generate Monthly Sales Report (CSV)", command=self._export_monthly_report).pack(fill="x", pady=6)
        ttk.Button(rep_box, text="💳 Export Pending Payments Report (CSV)", command=self._export_pending_report).pack(fill="x", pady=6)
        ttk.Button(rep_box, text="🚚 Export Pickup Schedule Report (CSV)", command=self._export_pickup_report).pack(fill="x", pady=6)
        ttk.Button(rep_box, text="📝 Generate Text Business Summary", command=self._generate_summary_txt).pack(fill="x", pady=6)

        # Tools & Maintenance Group
        tools_box = tk.LabelFrame(container, text=" 🗄️ Database Backup & Data Tools ", font=("Segoe UI", 10, "bold"), bg=self.card_bg, padx=15, pady=15)
        tools_box.pack(side="right", fill="both", expand=True)

        ttk.Button(tools_box, text="💾 Create Instant Database Backup", command=self._backup_db).pack(fill="x", pady=6)
        ttk.Button(tools_box, text="📂 Restore Database from Backup", command=self._restore_db).pack(fill="x", pady=6)
        ttk.Button(tools_box, text="📥 Bulk Import External Orders CSV", command=self._import_csv).pack(fill="x", pady=6)

    def _export_all_csv(self):
        s, p = rep_mod.export_all_orders_csv()
        if s:
            messagebox.showinfo("Export Successful", f"All orders exported to:\n{p}")
        else:
            messagebox.showerror("Error", p)

    def _export_daily_report(self):
        s, p, stats = rep_mod.generate_daily_sales_report()
        if s:
            messagebox.showinfo("Daily Report", f"Report saved to:\n{p}\nTotal Sales Today: ₹{stats['total_sales']:.2f}")
        else:
            messagebox.showerror("Error", p)

    def _export_monthly_report(self):
        s, p, stats = rep_mod.generate_monthly_sales_report()
        if s:
            messagebox.showinfo("Monthly Report", f"Report saved to:\n{p}\nTotal Sales Month: ₹{stats['total_sales']:.2f}")
        else:
            messagebox.showerror("Error", p)

    def _export_pending_report(self):
        s, p = rep_mod.generate_pending_payments_report()
        if s:
            messagebox.showinfo("Pending Payments", f"Report saved to:\n{p}")
        else:
            messagebox.showerror("Error", p)

    def _export_pickup_report(self):
        s, p = rep_mod.generate_pickup_schedule_report()
        if s:
            messagebox.showinfo("Pickup Schedule", f"Report saved to:\n{p}")
        else:
            messagebox.showerror("Error", p)

    def _generate_summary_txt(self):
        s, p, text = rep_mod.generate_text_summary()
        if s:
            messagebox.showinfo("Summary Generated", f"Summary saved to:\n{p}")
        else:
            messagebox.showerror("Error", p)

    def _backup_db(self):
        s, p = db.backup_data()
        if s:
            messagebox.showinfo("Backup Created", f"Data safely backed up to folder:\n{p}")
        else:
            messagebox.showerror("Backup Failed", p)

    def _restore_db(self):
        folder = filedialog.askdirectory(initialdir=str(config.BACKUP_DIR), title="Select Backup Folder to Restore")
        if folder:
            confirm = messagebox.askyesno("Confirm Restore", "Restoring will replace current orders and customer database with the backup copy. Proceed?")
            if confirm:
                s, msg = db.restore_data(folder)
                if s:
                    messagebox.showinfo("Restore Complete", msg)
                    self.refresh_all_views()
                else:
                    messagebox.showerror("Error", msg)

    def _import_csv(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")])
        if file_path:
            imported, skipped, errs = db.bulk_import_csv(file_path)
            self.refresh_all_views()
            msg = f"Bulk Import Finished:\n• Successfully imported: {imported} orders\n• Skipped / invalid: {skipped}"
            if errs:
                msg += f"\n\nFirst few notices:\n" + "\n".join(errs[:3])
            messagebox.showinfo("Import Results", msg)

    # -------------------------------------------------------------------------
    # GLOBAL REFRESH
    # -------------------------------------------------------------------------
    def refresh_all_views(self):
        """Reloads orders, customers, alerts, and analytics."""
        self.filter_orders_table()
        self.filter_customers_table()
        self._populate_alerts()
        self._populate_analytics()


def launch_gui():
    """Starts the Tkinter GUI mainloop."""
    app = BakeryDashboardGUI()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
