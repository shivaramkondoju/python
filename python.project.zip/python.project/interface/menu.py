"""Terminal Menu Interface for Bakery Order Register."""

import sys
from datetime import datetime, date
from typing import List, Dict, Any

import config
import storage.database as db
import modules.order as order_mod
import modules.customer as cust_mod
import modules.payment as pay_mod
import modules.pickup as pick_mod
import modules.search as search_mod
import modules.analytics as ana_mod
import modules.reports as rep_mod
import interface.forms as forms
from modules.calculation import calculate_total_amount


def print_header(title: str = "BAKERY ORDER REGISTER") -> None:
    """Prints a styled banner."""
    print("\n" + "=" * 68)
    print(f" {title.center(66)} ")
    print("=" * 68)


def display_orders_table(orders: List[Dict[str, Any]], title: str = "ORDERS REGISTER") -> None:
    """Prints a clean tabular view of orders."""
    if not orders:
        print("\n  [i] No orders found matching criteria.")
        return

    print_header(f"{title} ({len(orders)} Orders)")
    fmt = "{:<6} | {:<16} | {:<15} | {:<5} | {:<9} | {:<9} | {:<10} | {:<12}"
    divider = "-" * 95
    print(fmt.format("ID", "Customer", "Flavour", "Wt", "Total", "Pending", "Pickup", "Status"))
    print(divider)

    for o in orders:
        curr = "₹"
        wt = f"{float(o.get('weight_kg', 1.0)):.1f}k"
        tot = f"{curr}{float(o.get('total_amount', 0.0)):.0f}"
        pnd = f"{curr}{float(o.get('pending_amount', 0.0)):.0f}"
        cust = str(o.get("customer_name", ""))[:15]
        flav = str(o.get("flavour", ""))[:14]
        pick = str(o.get("pickup_date", ""))
        st = str(o.get("order_status", ""))[:12]

        print(fmt.format(
            o.get("order_id", ""),
            cust,
            flav,
            wt,
            tot,
            pnd,
            pick,
            st
        ))
    print(divider)


def menu_add_order() -> None:
    """Action 1: Register New Bakery Cake Order."""
    print_header("ADD NEW CAKE ORDER")
    
    name = forms.prompt_customer_name()
    phone = forms.prompt_mobile_number()
    address = input("Customer Address / Area [optional]: ").strip()
    
    cake_type = forms.prompt_cake_type()
    flavour, suggested_price = forms.prompt_flavour()
    weight = forms.prompt_weight(1.0)
    qty = forms.prompt_quantity(1)
    price_per_kg = forms.prompt_price_per_kg(suggested_price)
    extra_charges = forms.prompt_extra_charges(0.0)

    # Real-time calculation preview
    total = calculate_total_amount(price_per_kg, weight, qty, extra_charges)
    print(f"\n  >> Calculated Total Order Amount: ₹{total:.2f}")

    advance = forms.prompt_advance_payment(total, default=0.0)
    pending = total - advance
    print(f"  >> Pending Amount to Collect at Pickup: ₹{pending:.2f}")

    message = input("\nCake Inscription / Message (e.g. 'Happy Birthday Alex'): ").strip()
    notes = input("Special Instructions (Eggless, Less Sugar, Theme, etc.): ").strip()
    
    pickup_date = forms.prompt_pickup_date()
    pickup_time = input("Pickup Time (e.g. 17:30 or 5:30 PM) [18:00]: ").strip() or "18:00"

    success, new_order, msg = order_mod.register_new_order(
        customer_name=name,
        customer_phone=phone,
        cake_type=cake_type,
        flavour=flavour,
        weight_kg=weight,
        quantity=qty,
        cake_message=message,
        price_per_kg=price_per_kg,
        extra_charges=extra_charges,
        advance_paid=advance,
        pickup_date_str=pickup_date,
        pickup_time_str=pickup_time,
        order_status="Pending",
        special_notes=notes,
        customer_address=address
    )

    if success and new_order:
        print("\n" + "*" * 60)
        print(f"  [SUCCESS] {msg}")
        print(f"  Order ID       : {new_order['order_id']}")
        print(f"  Total Amount   : ₹{new_order['total_amount']:.2f}")
        print(f"  Advance Paid   : ₹{new_order['advance_paid']:.2f}")
        print(f"  Pending Balance: ₹{new_order['pending_amount']:.2f} ({new_order['payment_status']})")
        print(f"  Pickup Date    : {new_order['pickup_date']} at {new_order['pickup_time']}")
        print("*" * 60)

        gen_inv = input("\nDo you want to generate a printable receipt now? (y/n) [y]: ").strip().lower()
        if gen_inv != "n":
            _, inv_path, _ = rep_mod.generate_printable_invoice(new_order)
            print(f"  Receipt generated at: {inv_path}")
    else:
        print(f"\n  [ERROR] Failed to save order: {msg}")


def menu_view_all_orders() -> None:
    """Action 2: View All Orders."""
    orders = order_mod.get_all_orders()
    display_orders_table(orders, "ALL BAKERY ORDERS")


def menu_search_orders() -> None:
    """Action 3: Search and Filter Orders."""
    print_header("SEARCH & FILTER ORDERS")
    print("1. Search by Keyword (Order ID / Customer Name / Phone / Flavour)")
    print("2. Filter by Order Status (Pending, Preparing, Ready, Completed)")
    print("3. Filter by Payment Status (Paid, Partially Paid, Pending)")
    print("4. Filter by Pickup Date (Specific Date)")
    print("0. Back to Main Menu")

    choice = input("\nEnter search choice (0-4): ").strip()
    orders = order_mod.get_all_orders()

    if choice == "1":
        query = input("Enter search keyword: ").strip()
        results = search_mod.search_orders(orders, query=query)
        display_orders_table(results, f"Search Results for '{query}'")
    elif choice == "2":
        print("\nStatuses: Pending, Preparing, Ready for Pickup, Completed, Cancelled")
        st = input("Enter status: ").strip()
        results = search_mod.search_orders(orders, order_status=st)
        display_orders_table(results, f"Orders with Status '{st}'")
    elif choice == "3":
        print("\nPayment Statuses: Paid, Partially Paid, Pending")
        pst = input("Enter payment status: ").strip()
        results = search_mod.search_orders(orders, payment_status=pst)
        display_orders_table(results, f"Orders with Payment '{pst}'")
    elif choice == "4":
        pdate = forms.prompt_pickup_date(date.today().strftime("%Y-%m-%d"))
        results = search_mod.search_orders(orders, pickup_date=pdate)
        display_orders_table(results, f"Orders for Pickup on {pdate}")


def menu_update_order() -> None:
    """Action 4: Update Order Details."""
    print_header("UPDATE ORDER")
    oid = input("Enter Order ID to update (e.g. B001): ").strip().upper()
    order = order_mod.get_order_by_id(oid)

    if not order:
        print(f"  [!] Order '{oid}' not found.")
        return

    print("\nCurrent Order Details:")
    print(f"  Customer : {order.get('customer_name')} ({order.get('customer_phone')})")
    print(f"  Cake     : {order.get('cake_type')} - {order.get('flavour')} ({order.get('weight_kg')} kg)")
    print(f"  Total    : ₹{order.get('total_amount')} | Pending: ₹{order.get('pending_amount')} ({order.get('payment_status')})")
    print(f"  Pickup   : {order.get('pickup_date')} {order.get('pickup_time')} | Status: {order.get('order_status')}")

    print("\nSelect Field to Update:")
    print("1. Order Status (Pending, Preparing, Ready for Pickup, Completed, Cancelled)")
    print("2. Scheduled Pickup Date & Time")
    print("3. Cake Weight / Quantity")
    print("4. Cake Message & Inscription")
    print("5. Special Instructions")
    print("0. Cancel")

    ch = input("Enter choice (0-5): ").strip()
    updates = {}

    if ch == "1":
        print(f"Allowed statuses: {', '.join(config.ORDER_STATUSES)}")
        new_st = input("Enter new status: ").strip()
        updates["order_status"] = new_st
    elif ch == "2":
        new_date = forms.prompt_pickup_date(order.get("pickup_date"))
        new_time = input(f"Pickup Time [{order.get('pickup_time')}]: ").strip()
        updates["pickup_date"] = new_date
        if new_time:
            updates["pickup_time"] = new_time
    elif ch == "3":
        new_wt = forms.prompt_weight(float(order.get("weight_kg", 1.0)))
        new_qty = forms.prompt_quantity(int(order.get("quantity", 1)))
        updates["weight_kg"] = new_wt
        updates["quantity"] = new_qty
    elif ch == "4":
        new_msg = input(f"New Cake Message [{order.get('cake_message')}]: ").strip()
        updates["cake_message"] = new_msg
    elif ch == "5":
        new_notes = input(f"New Special Notes [{order.get('special_notes')}]: ").strip()
        updates["special_notes"] = new_notes
    else:
        print("  Update cancelled.")
        return

    success, updated, msg = order_mod.update_existing_order(oid, updates)
    if success:
        print(f"  [SUCCESS] {msg}")
    else:
        print(f"  [ERROR] {msg}")


def menu_delete_order() -> None:
    """Action 5: Delete Order."""
    print_header("DELETE ORDER")
    oid = input("Enter Order ID to delete: ").strip().upper()
    order = order_mod.get_order_by_id(oid)
    if not order:
        print(f"  [!] Order '{oid}' not found.")
        return

    print(f"  Are you sure you want to permanently delete Order {oid} for {order.get('customer_name')}?")
    confirm = input("Type 'YES' to confirm: ").strip()
    if confirm == "YES":
        success, msg = order_mod.delete_order(oid)
        print(f"  {msg}")
    else:
        print("  Deletion aborted.")


def menu_payment_management() -> None:
    """Action 6: Payment Tracking & Recording."""
    print_header("PAYMENT MANAGEMENT")
    print("1. Record Additional Payment")
    print("2. View All Orders with Pending Balance")
    print("3. View Low-Payment / High-Risk Alerts")
    print("4. Overall Payment Summary")
    print("0. Back")

    ch = input("\nEnter choice (0-4): ").strip()
    if ch == "1":
        oid = input("Enter Order ID: ").strip().upper()
        order = order_mod.get_order_by_id(oid)
        if not order:
            print(f"  [!] Order '{oid}' not found.")
            return

        print(f"  Customer       : {order.get('customer_name')}")
        print(f"  Total Amount   : ₹{order.get('total_amount'):.2f}")
        print(f"  Advance Paid   : ₹{order.get('advance_paid'):.2f}")
        print(f"  Pending Balance: ₹{order.get('pending_amount'):.2f}")

        if float(order.get("pending_amount", 0.0)) <= 0:
            print("  This order is already FULLY PAID.")
            return

        amt_str = input("Enter payment amount to collect (₹): ").strip()
        try:
            amt = float(amt_str)
            success, updated, msg = pay_mod.record_additional_payment(oid, amt)
            if success:
                print(f"  [SUCCESS] {msg}")
            else:
                print(f"  [ERROR] {msg}")
        except ValueError:
            print("  [!] Invalid numeric amount.")

    elif ch == "2":
        pending_list = pay_mod.get_pending_payment_orders()
        display_orders_table(pending_list, "PENDING BALANCE ORDERS")

    elif ch == "3":
        alerts = pay_mod.get_low_payment_alerts()
        display_orders_table(alerts, "LOW PAYMENT / UNPAID ACTIVE ORDERS")

    elif ch == "4":
        p_summary = pay_mod.get_payment_summary()
        print("\n" + "-" * 50)
        print("PAYMENT TOTALS:")
        print(f"  Total Order Value   : ₹{p_summary['total_order_value']:,.2f}")
        print(f"  Total Collected     : ₹{p_summary['total_collected']:,.2f}")
        print(f"  Total Pending       : ₹{p_summary['total_pending']:,.2f}")
        print(f"  Paid Orders         : {p_summary['status_counts']['Paid']}")
        print(f"  Partially Paid      : {p_summary['status_counts']['Partially Paid']}")
        print(f"  Unpaid (Pending)    : {p_summary['status_counts']['Pending']}")
        print("-" * 50)


def menu_pickup_management() -> None:
    """Action 7: Pickup Management & Order Tracking."""
    print_header("PICKUP & STATUS MANAGEMENT")
    print("1. Today's Pickups")
    print("2. Upcoming Pickups (Next 7 Days)")
    print("3. Overdue Pickups (Past Date Not Completed)")
    print("4. Quick Status Update (Mark Ready / Completed)")
    print("0. Back")

    ch = input("\nEnter choice (0-4): ").strip()
    if ch == "1":
        todays = pick_mod.get_todays_pickups()
        display_orders_table(todays, "TODAY'S PICKUP SCHEDULE")
    elif ch == "2":
        upcoming = pick_mod.get_upcoming_pickups(days=7)
        display_orders_table(upcoming, "UPCOMING PICKUPS (NEXT 7 DAYS)")
    elif ch == "3":
        overdue = pick_mod.get_overdue_pickups()
        display_orders_table(overdue, "OVERDUE PICKUPS (ACTION NEEDED)")
    elif ch == "4":
        oid = input("Enter Order ID: ").strip().upper()
        order = order_mod.get_order_by_id(oid)
        if not order:
            print(f"  [!] Order '{oid}' not found.")
            return

        print(f"  Current Status for {oid}: {order.get('order_status')}")
        print("  Select New Status:")
        print("    1. Preparing")
        print("    2. Ready for Pickup")
        print("    3. Completed")
        print("    4. Cancelled")

        st_ch = input("  Choice (1-4): ").strip()
        status_map = {
            "1": "Preparing",
            "2": "Ready for Pickup",
            "3": "Completed",
            "4": "Cancelled"
        }
        if st_ch in status_map:
            success, _, msg = pick_mod.update_order_status(oid, status_map[st_ch])
            print(f"  {msg}")
        else:
            print("  [!] Invalid choice.")


def menu_business_summary() -> None:
    """Action 8: Business Analytics & Summary."""
    print_header("BUSINESS ANALYTICS & DASHBOARD SUMMARY")
    summary = ana_mod.get_business_summary()

    curr = config.BAKERY_INFO["currency_symbol"]
    print(f"Total Orders Registered : {summary['total_orders']}")
    print(f"Completed Orders        : {summary['completed_orders']}")
    print(f"Active Orders           : {summary['active_orders']}")
    print(f"Cancelled Orders        : {summary['cancelled_orders']}")
    print("-" * 55)
    print(f"Total Revenue / Sales   : {curr}{summary['total_revenue']:,.2f}")
    print(f"Advance Collected       : {curr}{summary['total_collected']:,.2f}")
    print(f"Pending Balance to Collect: {curr}{summary['total_pending']:,.2f}")
    print(f"Average Order Value     : {curr}{summary['average_order_value']:,.2f}")
    print("-" * 55)

    print("Top 5 Customer Favorite Flavours:")
    for flav, cnt in summary["popular_flavours"]:
        print(f"  - {flav:<20}: {cnt} orders")

    gen_chart = input("\nGenerate Sales Analytics Chart (PNG image)? (y/n) [y]: ").strip().lower()
    if gen_chart != "n":
        chart_path = ana_mod.generate_sales_charts()
        if chart_path:
            print(f"  [SUCCESS] Analytics chart saved to: {chart_path}")
        else:
            print("  [!] Could not generate chart (Matplotlib required).")


def menu_export_reports() -> None:
    """Action 9: Export Reports."""
    print_header("REPORT GENERATION & EXPORT")
    print("1. Export All Orders to CSV")
    print("2. Generate Daily Sales Report (CSV)")
    print("3. Generate Monthly Sales Report (CSV)")
    print("4. Export Pending Payments Report (CSV)")
    print("5. Export Pickup Schedule (CSV)")
    print("6. Generate Text Summary File (summary.txt)")
    print("7. Generate Customer Invoice Receipt (TXT)")
    print("0. Back")

    ch = input("\nEnter choice (0-7): ").strip()
    if ch == "1":
        s, path = rep_mod.export_all_orders_csv()
        print(f"  [SUCCESS] All orders exported to: {path}" if s else f"  [ERROR] {path}")
    elif ch == "2":
        dt = input(f"Enter date (YYYY-MM-DD) [{date.today().strftime('%Y-%m-%d')}]: ").strip()
        s, path, stats = rep_mod.generate_daily_sales_report(dt or None)
        if s:
            print(f"  [SUCCESS] Daily report saved to: {path}")
            print(f"  Total sales on {stats['date']}: ₹{stats['total_sales']:.2f} ({stats['count']} orders)")
        else:
            print(f"  [ERROR] {path}")
    elif ch == "3":
        m = input(f"Enter month (YYYY-MM) [{date.today().strftime('%Y-%m')}]: ").strip()
        s, path, stats = rep_mod.generate_monthly_sales_report(m or None)
        if s:
            print(f"  [SUCCESS] Monthly report saved to: {path}")
            print(f"  Total sales in {stats['month']}: ₹{stats['total_sales']:.2f} ({stats['count']} orders)")
        else:
            print(f"  [ERROR] {path}")
    elif ch == "4":
        s, path = rep_mod.generate_pending_payments_report()
        print(f"  [SUCCESS] Pending payments report saved to: {path}" if s else f"  [ERROR] {path}")
    elif ch == "5":
        s, path = rep_mod.generate_pickup_schedule_report()
        print(f"  [SUCCESS] Pickup schedule report saved to: {path}" if s else f"  [ERROR] {path}")
    elif ch == "6":
        s, path, text = rep_mod.generate_text_summary()
        if s:
            print(f"  [SUCCESS] Text summary saved to: {path}")
            print(text)
        else:
            print(f"  [ERROR] {path}")
    elif ch == "7":
        oid = input("Enter Order ID for receipt: ").strip().upper()
        order = order_mod.get_order_by_id(oid)
        if not order:
            print(f"  [!] Order '{oid}' not found.")
            return
        s, path, receipt = rep_mod.generate_printable_invoice(order)
        if s:
            print(f"  [SUCCESS] Invoice saved to: {path}")
            print("\n" + receipt)
        else:
            print(f"  [ERROR] {path}")


def run_terminal_menu() -> None:
    """Main application terminal loop."""
    db.init_storage()

    while True:
        print_header("BAKERY ORDER REGISTER")
        print("  1. Add New Order")
        print("  2. View All Orders")
        print("  3. Search Order")
        print("  4. Update Order")
        print("  5. Delete Order")
        print("  6. Payment Management")
        print("  7. Pickup Management")
        print("  8. Business Summary")
        print("  9. Export Reports")
        print(" 10. Exit")
        print("=" * 68)

        choice = input("Enter your choice (1-10): ").strip()

        if choice == "1":
            menu_add_order()
        elif choice == "2":
            menu_view_all_orders()
        elif choice == "3":
            menu_search_orders()
        elif choice == "4":
            menu_update_order()
        elif choice == "5":
            menu_delete_order()
        elif choice == "6":
            menu_payment_management()
        elif choice == "7":
            menu_pickup_management()
        elif choice == "8":
            menu_business_summary()
        elif choice == "9":
            menu_export_reports()
        elif choice == "10":
            print("\nThank you for using Bakery Order Register!")
            backup_choice = input("Create database backup before quitting? (y/n) [y]: ").strip().lower()
            if backup_choice != "n":
                s, bpath = db.backup_data()
                if s:
                    print(f"Backup created at: {bpath}")
            print("Goodbye!")
            break
        else:
            print("  [!] Invalid choice! Please enter a number between 1 and 10.")

        input("\nPress Enter to return to main menu...")
