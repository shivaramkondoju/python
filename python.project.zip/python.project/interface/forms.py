"""CLI Input Form Prompts with Validation for Bakery Order Register."""

from datetime import date
from typing import Tuple, Optional

import config
from modules.validation import (
    validate_customer_name,
    validate_mobile_number,
    validate_weight,
    validate_quantity,
    validate_price,
    validate_advance_payment,
    validate_date,
    sanitize_string
)


def prompt_customer_name(default: str = "") -> str:
    """Prompts for customer name with validation."""
    while True:
        prompt_text = f"Customer Name [{default}]: " if default else "Customer Name: "
        user_input = input(prompt_text).strip()
        if not user_input and default:
            return default
        is_valid, res = validate_customer_name(user_input)
        if is_valid:
            return res
        print(f"  [!] Error: {res}")


def prompt_mobile_number(default: str = "") -> str:
    """Prompts for Indian mobile number (10 digits)."""
    while True:
        prompt_text = f"Mobile Number (10 digits) [{default}]: " if default else "Mobile Number (10 digits): "
        user_input = input(prompt_text).strip()
        if not user_input and default:
            return default
        is_valid, res = validate_mobile_number(user_input)
        if is_valid:
            return res
        print(f"  [!] Error: {res}")


def prompt_cake_type(default: str = "Birthday Cake") -> str:
    """Prompts user to select or enter a cake type."""
    print("\nSelect Cake Type:")
    for idx, ctype in enumerate(config.CAKE_TYPES, 1):
        print(f"  {idx}. {ctype}")
    print(f"  0. Other / Custom")

    while True:
        choice = input(f"Enter choice (1-{len(config.CAKE_TYPES)}, 0=Custom) [default '{default}']: ").strip()
        if not choice:
            return default
        if choice == "0":
            custom_type = input("Enter custom cake type: ").strip()
            return custom_type if custom_type else default
        if choice.isdigit() and 1 <= int(choice) <= len(config.CAKE_TYPES):
            return config.CAKE_TYPES[int(choice) - 1]
        print("  [!] Invalid selection! Please enter a number from the list.")


def prompt_flavour(default: str = "Chocolate Truffle") -> Tuple[str, float]:
    """Prompts user to select cake flavour with standard price per kg."""
    flavours = list(config.FLAVOUR_BASE_PRICES.keys())
    print("\nSelect Cake Flavour:")
    for idx, flav in enumerate(flavours, 1):
        rate = config.FLAVOUR_BASE_PRICES[flav]
        print(f"  {idx:2d}. {flav:<20} (₹{rate:.0f}/kg)")
    print("   0. Custom Flavour")

    while True:
        choice = input(f"Enter choice (1-{len(flavours)}, 0=Custom) [default '{default}']: ").strip()
        if not choice:
            return default, config.FLAVOUR_BASE_PRICES.get(default, 600.0)
        if choice == "0":
            custom_fl = input("Enter custom flavour: ").strip()
            return (custom_fl if custom_fl else "Custom Flavour"), 600.0
        if choice.isdigit() and 1 <= int(choice) <= len(flavours):
            selected = flavours[int(choice) - 1]
            return selected, config.FLAVOUR_BASE_PRICES[selected]
        print("  [!] Invalid selection! Please enter a number from the list.")


def prompt_weight(default: float = 1.0) -> float:
    """Prompts for cake weight in kg."""
    while True:
        user_input = input(f"Cake Weight in kg (e.g. 1.0, 1.5, 2.0) [{default}]: ").strip()
        if not user_input:
            return default
        is_valid, val, err = validate_weight(user_input)
        if is_valid:
            return val
        print(f"  [!] Error: {err}")


def prompt_quantity(default: int = 1) -> int:
    """Prompts for quantity."""
    while True:
        user_input = input(f"Quantity (units) [{default}]: ").strip()
        if not user_input:
            return default
        is_valid, val, err = validate_quantity(user_input)
        if is_valid:
            return val
        print(f"  [!] Error: {err}")


def prompt_price_per_kg(suggested_price: float) -> float:
    """Prompts or confirms price per kg."""
    while True:
        user_input = input(f"Price per kg (₹) [{suggested_price:.0f}]: ").strip()
        if not user_input:
            return suggested_price
        is_valid, val, err = validate_price(user_input, allow_zero=False)
        if is_valid:
            return val
        print(f"  [!] Error: {err}")


def prompt_extra_charges(default: float = 0.0) -> float:
    """Prompts for decoration or extra charges."""
    presets = list(config.EXTRA_CHARGES_PRESETS.items())
    print("\nExtra / Decoration Charges:")
    for idx, (name, charge) in enumerate(presets, 1):
        print(f"  {idx}. {name:<32} (+₹{charge:.0f})")
    print("  0. Custom Amount")

    while True:
        choice = input(f"Select preset (1-{len(presets)}, 0=Custom) [default ₹{default:.0f}]: ").strip()
        if not choice:
            return default
        if choice == "0":
            custom_amt = input("Enter custom extra charge (₹): ").strip()
            is_valid, val, err = validate_price(custom_amt, allow_zero=True)
            if is_valid:
                return val
            print(f"  [!] Error: {err}")
            continue
        if choice.isdigit() and 1 <= int(choice) <= len(presets):
            return presets[int(choice) - 1][1]
        print("  [!] Invalid choice.")


def prompt_advance_payment(total_amount: float, default: float = 0.0) -> float:
    """Prompts for advance payment with validation against total."""
    while True:
        user_input = input(f"Advance Payment (₹) (Max ₹{total_amount:.2f}) [{default:.0f}]: ").strip()
        if not user_input:
            return default
        is_valid, val, err = validate_advance_payment(user_input, total_amount)
        if is_valid:
            return val
        print(f"  [!] Error: {err}")


def prompt_pickup_date(default: Optional[str] = None) -> str:
    """Prompts for pickup date (YYYY-MM-DD) not in the past."""
    if not default:
        default = date.today().strftime("%Y-%m-%d")
    while True:
        user_input = input(f"Pickup Date (YYYY-MM-DD) [{default}]: ").strip()
        if not user_input:
            user_input = default
        is_valid, norm_date, err = validate_date(user_input, allow_past=False)
        if is_valid:
            return norm_date
        print(f"  [!] Error: {err}")
