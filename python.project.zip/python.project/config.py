"""Configuration and Constants for Bakery Order Register Application."""

import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
MODULES_DIR = BASE_DIR / "modules"
STORAGE_DIR = BASE_DIR / "storage"
INTERFACE_DIR = BASE_DIR / "interface"
REPORTS_DIR = BASE_DIR / "reports"
TESTS_DIR = BASE_DIR / "tests"
ASSETS_DIR = BASE_DIR / "assets"
BACKUP_DIR = STORAGE_DIR / "backups"

# Ensure runtime directories exist
for folder in [STORAGE_DIR, REPORTS_DIR, TESTS_DIR, ASSETS_DIR, BACKUP_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

# Data File Paths
ORDERS_CSV = STORAGE_DIR / "orders.csv"
CUSTOMERS_JSON = STORAGE_DIR / "customers.json"
APP_CONFIG_JSON = STORAGE_DIR / "settings.json"

# Bakery Branding Information
BAKERY_INFO = {
    "name": "Sweet Delights Bakery & Cake Studio",
    "tagline": "Freshly Baked Happiness for Every Occasion",
    "phone": "+91 98765 43210",
    "email": "orders@sweetdelightsbakery.com",
    "address": "Shop #14, Royal Heritage Arcade, Road No. 12, Banjara Hills, Hyderabad - 500034",
    "fssai_lic": "FSSAI Lic: 13622011000452",
    "currency_symbol": "₹",
    "currency_code": "INR"
}

# Cake Types
CAKE_TYPES = [
    "Birthday Cake",
    "Wedding Cake",
    "Anniversary Cake",
    "Designer Fondant Cake",
    "Photo Cake",
    "Cupcake Set",
    "Pastry Box",
    "Tea Cake"
]

# Cake Flavours with Standard Base Price per Kg (in INR)
FLAVOUR_BASE_PRICES = {
    "Chocolate Truffle": 650.0,
    "Black Forest": 550.0,
    "Red Velvet": 700.0,
    "Fresh Strawberry": 600.0,
    "Butterscotch": 550.0,
    "Vanilla Bean": 500.0,
    "Pineapple": 500.0,
    "Mango Delight": 600.0,
    "Choco Fudge": 650.0,
    "Blueberry Cream": 700.0,
    "Rasmalai Fusion": 750.0,
    "Coffee Hazelnut": 750.0
}

# Standard Statuses
ORDER_STATUSES = [
    "Pending",
    "Preparing",
    "Ready for Pickup",
    "Completed",
    "Cancelled"
]

PAYMENT_STATUSES = [
    "Paid",
    "Partially Paid",
    "Pending"
]

# Common Extra Charges presets
EXTRA_CHARGES_PRESETS = {
    "None": 0.0,
    "Custom Fondant Toppers": 200.0,
    "Edible Photo Print": 150.0,
    "Special Delivery Box & Sparkler": 100.0,
    "Sugar-Free / Keto Preparation": 250.0,
    "Eggless Premium Preparation": 100.0
}

# CSV Column Order
CSV_FIELDNAMES = [
    "order_id",
    "customer_id",
    "customer_name",
    "customer_phone",
    "cake_type",
    "flavour",
    "weight_kg",
    "quantity",
    "cake_message",
    "price_per_kg",
    "extra_charges",
    "total_amount",
    "advance_paid",
    "pending_amount",
    "payment_status",
    "order_date",
    "pickup_date",
    "pickup_time",
    "order_status",
    "special_notes"
]
