"""Main Entry Point for Bakery Order Register Application.

Supports both Tkinter Graphical User Interface (GUI) and Terminal Interactive CLI.
"""

import sys
import argparse
from pathlib import Path

# Add project root to sys.path so modules can be imported directly
sys.path.insert(0, str(Path(__file__).resolve().parent))

import storage.database as db
from interface.menu import run_terminal_menu


def main():
    """Main launcher."""
    parser = argparse.ArgumentParser(description="Bakery Order Register Application (Hackathon Project #87)")
    parser.add_argument("--cli", "-c", action="store_true", help="Launch interactive Terminal Command-Line Interface")
    parser.add_argument("--gui", "-g", action="store_true", help="Launch modern Tkinter Graphical User Interface")
    args = parser.parse_args()

    # Initialize data storage files if not already present
    db.init_storage()

    if args.cli:
        run_terminal_menu()
        return

    if args.gui:
        try:
            from interface.dashboard import launch_gui
            launch_gui()
            return
        except Exception as e:
            print(f"[!] Unable to launch GUI: {e}")
            print("[i] Falling back to Terminal Interface...")
            run_terminal_menu()
            return

    # Default behaviour: Check if Tkinter is available and can open a display window
    try:
        import tkinter
        # Test if display can be initialized
        root = tkinter.Tk()
        root.withdraw()
        root.destroy()
        from interface.dashboard import launch_gui
        launch_gui()
    except Exception as e:
        print("Note: Running in Terminal mode (use --gui to force GUI window).")
        run_terminal_menu()


if __name__ == "__main__":
    main()
